const CLIENT_URL = 'https://esm.sh/@supabase/supabase-js@2.45.4';
const EMAIL_DOMAIN = 'spokum.app';

const ms = (value) => (value ? Date.parse(value) : 0);
const emailFor = (username) => `${username}@${EMAIL_DOMAIN}`;

function normalizePins(value) {
  if (!Array.isArray(value)) return [];
  return value
    .map((pin, index) => {
      if (typeof pin === 'string') {
        return { image: pin, x: [12, 78, 12, 78][index] ?? 50, y: [16, 16, 66, 66][index] ?? 50 };
      }
      if (pin && typeof pin.image === 'string') {
        return {
          image: pin.image,
          x: Math.min(94, Math.max(2, Number(pin.x) || 50)),
          y: Math.min(90, Math.max(2, Number(pin.y) || 50))
        };
      }
      return null;
    })
    .filter(Boolean)
    .slice(0, 4);
}

function shapeProfile(row, extra = {}) {
  if (!row) return null;
  return {
    id: row.id,
    username: row.username,
    loginName: row.login_name || row.username,
    displayName: row.display_name || row.username,
    bio: row.bio || '',
    hue: row.hue ?? 220,
    avatar: row.avatar || null,
    mood: row.mood || 'calm',
    theme: row.theme || 'calm',
    accent: row.accent || 'mint',
    isAdmin: !!row.is_admin,
    isModerator: !!row.is_moderator,
    isDeveloper: !!row.is_developer,
    isVerified: !!row.is_verified,
    modRank: row.mod_rank ?? 0,
    isBeta: !!row.is_beta || row.username === 'silver',
    coins: row.coins ?? 0,
    streakDays: row.streak_days ?? 0,
    bestStreak: row.best_streak ?? 0,
    bannedUntil: ms(row.banned_until),
    mutedUntil: ms(row.muted_until),
    createdAt: ms(row.created_at),
    lastSeen: ms(row.last_seen),
    pins: normalizePins(row.pins),
    shelf: Array.isArray(row.shelf) ? row.shelf : [],
    banner: row.banner || null,
    dayWord: row.day_word || null,
    dayWordAt: ms(row.day_word_at),
    shareWord: !!row.share_word,
    notifyPosts: row.notify_posts !== false,
    statusIcon: row.status_icon || null,
    premiumUntil: ms(row.premium_until),
    premiumReason: row.premium_reason || '',
    premiumGrantedAt: ms(row.premium_granted_at),
    likes: Number(row.like_count ?? extra.likes ?? 0),
    posts: Number(row.post_count ?? extra.posts ?? 0),
    strikes: Number(row.strikes ?? 0)
  };
}

function shapePost(row, likedIds, extra = {}) {
  return {
    id: row.id,
    text: row.body || '',
    image: row.image || null,
    mood: row.mood || 'calm',
    createdAt: ms(row.created_at),
    removed: !!row.removed,
    removedReason: row.removed_reason || '',
    removedAuto: !!row.removed_auto,
    author: shapeProfile(row.author),
    likes: row.likes?.[0]?.count ?? 0,
    comments: row.comments?.[0]?.count ?? 0,
    liked: likedIds ? likedIds.has(row.id) : false,
    kind: row.kind || 'text',
    media: Array.isArray(row.media) ? row.media : [],
    video: row.video || null,
    poster: row.poster || null,
    duration: row.duration || 0,
    views: row.views || 0,
    sound: row.sound || null,
    poll: row.poll || null,
    pinned: !!row.pinned,
    publishAt: ms(row.publish_at),
    repostOf: row.repost_of || null,
    origin: extra.origin || null
  };
}

function shapeMessage(row, authors) {
  return {
    id: row.id,
    chatId: row.chat_id,
    kind: row.kind,
    body: row.body || '',
    media: row.media || null,
    duration: row.duration || 0,
    postId: row.post_id || null,
    createdAt: ms(row.created_at),
    author: shapeProfile(row.author || authors?.get(row.author_id))
  };
}

function guard(error) {
  if (!error) return;
  const text = error.message || 'Ошибка запроса';
  if (/abort|timed? ?out|timeout/i.test(text)) {
    throw new Error('Сервер не ответил вовремя. Попробуйте ещё раз');
  }
  if (/failed to fetch|networkerror|load failed|network request failed/i.test(text)) {
    throw new Error(
      navigator.onLine
        ? 'Сервер не отвечает. Проверьте адрес базы в config.js или попробуйте позже'
        : 'Нет интернета'
    );
  }
  if (/row-level security|permission denied/i.test(text)) throw new Error('Недостаточно прав');
  if (/duplicate key/i.test(text) && /username/i.test(text)) throw new Error('Юзернейм занят');
  if (/already registered|User already/i.test(text)) throw new Error('Такой аккаунт уже есть');
  if (/Invalid login credentials/i.test(text)) throw new Error('Неверный логин или пароль');
  if (/signups? (are )?disabled|signups not allowed/i.test(text)) {
    throw new Error('В базе данных выключена регистрация: Authentication → Sign In / Providers → Email → включить Allow new users to sign up');
  }
  if (/email logins are disabled|email provider/i.test(text)) {
    throw new Error('В базе данных выключен вход по почте: Authentication → Sign In / Providers → включить Email');
  }
  throw new Error(text);
}

const REQUEST_TIMEOUT = 30000;

function timedFetch(input, init = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT);
  if (init.signal) {
    init.signal.addEventListener('abort', () => controller.abort(), { once: true });
  }
  return fetch(input, { ...init, signal: controller.signal }).finally(() => clearTimeout(timer));
}

function withTimeout(promise, ms, fallback) {
  return Promise.race([
    promise,
    new Promise((done) => setTimeout(() => done(fallback), ms))
  ]);
}

async function loadFactory() {
  if (window.supabase?.createClient) return window.supabase.createClient;
  const module = await import(CLIENT_URL);
  return module.createClient;
}

export async function createBackend(url, key) {
  const createClient = await loadFactory();
  const sb = createClient(url, key, {
    auth: { persistSession: true, autoRefreshToken: false, detectSessionInUrl: false, flowType: 'refresh' },
    global: { fetch: timedFetch },
    realtime: { params: { eventsPerSecond: 4 } }
  });

  let uid = null;
  let channel = null;
  let leaving = false;
  let restoring = null;
  let lastSuccessTime = 0;
  let signOutTimer = null;

  const requireUid = () => {
    if (!uid) throw new Error('Нужен вход');
    return uid;
  };

  const profileById = async (id) => {
    const { data, error } = await sb.from('profiles').select('*').eq('id', id).maybeSingle();
    guard(error);
    if (!data) return null;
    return shapeProfile(data, await counters(id));
  };

  const counters = async (id) => {
    const posts = await sb.from('posts').select('id', { count: 'exact', head: true }).eq('author_id', id).eq('removed', false);
    const ids = await sb.from('posts').select('id').eq('author_id', id).eq('removed', false);
    let likes = 0;
    if (ids.data?.length) {
      const result = await sb
        .from('likes')
        .select('post_id', { count: 'exact', head: true })
        .in('post_id', ids.data.map((row) => row.id));
      likes = result.count || 0;
    }
    return { posts: posts.count || 0, likes };
  };

  const likedSet = async (postIds) => {
    if (!uid || !postIds.length) return new Set();
    const { data } = await sb.from('likes').select('post_id').eq('user_id', uid).in('post_id', postIds);
    return new Set((data || []).map((row) => row.post_id));
  };

  async function withOrigins(rows) {
    const ids = [...new Set(rows.map((row) => row.repost_of).filter(Boolean))];
    if (!ids.length) return new Map();
    const { data } = await sb
      .from('posts')
      .select('id, author:profiles!posts_author_id_fkey(username, display_name, avatar, hue)')
      .in('id', ids);
    const map = new Map();
    (data || []).forEach((row) => {
      if (row.author) {
        map.set(row.id, {
          username: row.author.username,
          displayName: row.author.display_name || row.author.username,
          avatar: row.author.avatar || null,
          hue: row.author.hue ?? 220
        });
      }
    });
    return map;
  }

  const POST_CORE = 'id, body, image, mood, created_at, removed, removed_reason';
  const AUTHOR_FIELDS = 'id, username, display_name, avatar, hue, mood, is_admin, is_moderator, is_developer, is_verified, mod_rank, premium_until, status_icon, is_beta';
  const POST_TAIL = `author:profiles!posts_author_id_fkey(${AUTHOR_FIELDS}), likes(count), comments(count)`;
  const POST_TIERS = [
    `${POST_CORE}, removed_auto, kind, media, video, poster, duration, views, sound, poll, pinned, publish_at, repost_of, ${POST_TAIL}`,
    `${POST_CORE}, kind, media, video, poster, duration, views, sound, poll, pinned, publish_at, repost_of, ${POST_TAIL}`,
    `${POST_CORE}, kind, media, video, poster, duration, views, sound, poll, pinned, repost_of, ${POST_TAIL}`,
    `${POST_CORE}, kind, media, video, poster, duration, views, ${POST_TAIL}`,
    `${POST_CORE}, ${POST_TAIL}`
  ];
  let postTier = 0;
  let legacyPosts = false;
  const POST_SELECT = () => POST_TIERS[postTier];
  const dropTier = () => {
    if (postTier >= POST_TIERS.length - 1) return false;
    postTier += 1;
    legacyPosts = postTier >= POST_TIERS.length - 1;
    return true;
  };
  let later = true;
  const missingColumn = (error) => !!error && (error.code === '42703' || /column .* does not exist/i.test(error.message || ''));

  const uploadData = async (dataUrl, hint = 'jpg') => {
    const me = uid;
    if (!me) throw new Error('Нужен вход');
    const response = await fetch(dataUrl);
    const blob = await response.blob();
    const known = /^(video|image)\//.test(blob.type || '') ? blob.type.split(';')[0] : '';
    const type = known || 'image/jpeg';
    const ext = (type.split('/')[1] || 'jpg').replace('quicktime', 'mov');
    const path = `${me}/${hint}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
    const upload = await sb.storage.from('media').upload(path, blob, { contentType: type, upsert: false });
    if (upload.error) throw new Error(upload.error.message);
    const { data } = sb.storage.from('media').getPublicUrl(path);
    return data.publicUrl;
  };

  const lighten = async (value, hint) => {
    if (typeof value !== 'string' || !value.startsWith('data:')) return value;
    if (value.length < 24000) return value;
    try {
      return await uploadData(value, hint);
    } catch {
      return value;
    }
  };

  const wake = () => {
    if (!uid) return;
    const state = channel?.state;
    if (state === 'joined' || state === 'joining') return;
    if (channel) {
      try {
        sb.removeChannel(channel);
      } catch {}
      channel = null;
    }
    try {
      sb.realtime?.connect?.();
    } catch {}
    listen();
  };

  const listen = () => {
    if (channel || !uid) return;
    channel = sb
      .channel('spokum-messages')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, (payload) => {
        window.dispatchEvent(new CustomEvent('spokum:message', { detail: payload.new }));
      })
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'notifications', filter: `user_id=eq.${uid}` }, (payload) => {
        const row = payload.new;
        window.dispatchEvent(new CustomEvent('spokum:notify', {
          detail: { id: row.id, kind: row.kind, title: row.title, body: row.body, meta: row.meta || {}, createdAt: ms(row.created_at), read: false }
        }));
      })
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'call_signals', filter: `to_id=eq.${uid}` }, (payload) => {
        const row = payload.new;
        window.dispatchEvent(new CustomEvent('spokum:call', {
          detail: { id: row.id, chatId: row.chat_id, fromId: row.from_id, kind: row.kind, payload: row.payload || {} }
        }));
      })
      .subscribe((status) => {
        if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT' || status === 'CLOSED') {
          setTimeout(() => {
            if (channel?.state === 'joined') return;
            try {
              sb.removeChannel(channel);
            } catch {}
            channel = null;
            listen();
          }, 2500);
        }
      });
  };

  const KEEP_KEY = 'spokum.me.cache';

  const keepProfile = (user) => {
    if (!user?.id) return;
    try {
      localStorage.setItem(KEEP_KEY, JSON.stringify({ at: Date.now(), user }));
    } catch {}
  };

  const keptProfile = () => {
    try {
      const row = JSON.parse(localStorage.getItem(KEEP_KEY) || 'null');
      if (row?.user?.id) return row.user;
    } catch {}
    return null;
  };

  const storedSession = () => {
    try {
      for (let i = 0; i < localStorage.length; i += 1) {
        const key = localStorage.key(i);
        if (!key || !/^sb-.*-auth-token$/.test(key)) continue;
        const row = JSON.parse(localStorage.getItem(key) || 'null');
        const who = row?.user?.id || row?.currentSession?.user?.id;
        if (who) return who;
      }
    } catch {}
    return null;
  };

  
  
  const KEEP_SESSION = 'spokum.session.keep';
  let sessionLost = false;

  const keepSession = (session) => {
    if (!session?.refresh_token) return;
    try {
      localStorage.setItem(KEEP_SESSION, JSON.stringify({
        at: Date.now(),
        id: session.user?.id || uid || '',
        access_token: session.access_token || '',
        refresh_token: session.refresh_token
      }));
      sessionLost = false;
    } catch {}
    
    
    
    if (window.SpokumHost?.setAuth) {
      try {
        window.SpokumHost.setAuth(url, key, session.refresh_token);
      } catch {}
    }
  };

  const keptSession = () => {
    try {
      const row = JSON.parse(localStorage.getItem(KEEP_SESSION) || 'null');
      if (row?.refresh_token) return row;
    } catch {}
    return null;
  };

  const dropKeptSession = () => {
    try {
      localStorage.removeItem(KEEP_SESSION);
    } catch {}
  };

  const pause = (ms) => new Promise((done) => setTimeout(done, ms));

  
  
  
  const liveSession = async () => {
    try {
      const { data } = await withTimeout(sb.auth.getSession(), 6000, { data: null });
      return data?.session || null;
    } catch {
      return null;
    }
  };

  const restoreSession = async (tries = 3) => {
    if (restoring) return restoring;
    if (leaving || !navigator.onLine) {
      return null;
    }
    const kept = keptSession();
    if (!kept?.refresh_token) {
      return null;
    }
    restoring = (async () => {
      const already = await liveSession();
      if (already?.user?.id) {
        uid = already.user.id;
        keepSession(already);
        sessionLost = false;
        lastSuccessTime = Date.now();
        listen();
        return uid;
      }
      for (let attempt = 1; attempt <= tries; attempt += 1) {
        const copy = keptSession();
        if (!copy?.refresh_token || leaving) {
          return null;
        }
        try {
          const { data, error } = copy.access_token
            ? await sb.auth.setSession({ access_token: copy.access_token, refresh_token: copy.refresh_token })
            : await sb.auth.refreshSession({ refresh_token: copy.refresh_token });
          if (error) {
            throw error;
          }
          const fresh = data?.session || null;
          const who = fresh?.user?.id || data?.user?.id || null;
          if (who) {
            uid = who;
            if (fresh) keepSession(fresh);
            sessionLost = false;
            lastSuccessTime = Date.now();
            listen();
            return who;
          }
          return null;
        } catch (error) {
          const text = error?.message || '';
          if (/already used/i.test(text)) {
            if (attempt < tries) await pause(2000 * attempt);
            continue;
          }
          if (/invalid|revoked|expired|not found|no such/i.test(text)) {
            sessionLost = true;
            return null;
          }
          if (attempt < tries) await pause(1500 * attempt);
        }
      }
      return null;
    })().finally(() => {
      restoring = null;
    });
    return restoring;
  };

  const sessionResult = await withTimeout(sb.auth.getSession(), 8000, { data: { session: null } });
  const firstSession = sessionResult?.data?.session || null;
  if (firstSession) keepSession(firstSession);
  uid = firstSession?.user?.id || storedSession() || null;
  
  
  
  if (!uid) uid = await restoreSession(navigator.onLine ? 4 : 0);
  if (uid) listen();
  setInterval(() => {
    if (uid && !leaving && navigator.onLine && Date.now() - lastSuccessTime > 25 * 60 * 1000) {
      restoreSession(1).catch(() => {});
    }
  }, 5 * 60 * 1000);

  sb.auth.onAuthStateChange((event, session) => {
    if (session) {
      keepSession(session);
      uid = session.user?.id || uid;
      lastSuccessTime = Date.now();
      sessionLost = false;
      listen();
      return;
    }
    if (event === 'INITIAL_SESSION' && !session) {
      if (!leaving && !uid) setTimeout(() => restoreSession(2).catch(() => {}), 0);
      return;
    }
    if (event === 'SIGNED_OUT' || event === 'USER_DELETED') {
      if (leaving) {
        uid = null;
        return;
      }
      if (signOutTimer) clearTimeout(signOutTimer);
      signOutTimer = setTimeout(async () => {
        signOutTimer = null;
        if (Date.now() - lastSuccessTime < 15000) {
          return;
        }
        const restored = await restoreSession(3).catch(() => null);
        if (!restored && !leaving) {
          uid = null;
          sessionLost = true;
        }
      }, 3000);
      return;
    }
  });

  return {
    mode: 'supabase',

    wake,

    realtimeUp() {
      return channel?.state === 'joined';
    },

    async register({ username, displayName, password }) {
      const name = String(username || '').toLowerCase().replace(/^@/, '');
      if (!/^[a-z0-9_]{3,20}$/.test(name)) throw new Error('Юзернейм: 3-20 символов, латиница, цифры и _');
      if (String(password || '').length < 8) throw new Error('Пароль минимум 8 символов');
      const taken = await sb.from('profiles').select('id').eq('username', name).maybeSingle();
      if (taken.data) throw new Error('Юзернейм занят');
      const alias = await sb.from('usernames').select('user_id').eq('username', name).maybeSingle();
      if (alias.data) throw new Error('Юзернейм занят');
      const { data, error } = await sb.auth.signUp({
        email: emailFor(name),
        password,
        options: { data: { username: name, display_name: displayName || name } }
      });
      guard(error);
      if (!data.session) throw new Error('Подтверждение почты включено в базе данных, выключите его в Authentication → Providers → Email');
      uid = data.user.id;
      if (data.session) keepSession(data.session);
      const user = await profileById(uid);
      keepProfile(user); 
      listen();
      return { user };
    },

    async login({ username, password }) {
      const name = String(username || '').toLowerCase().replace(/^@/, '');
      let handle = name;
      try {
        const resolved = await sb.rpc('resolve_login', { target: name });
        if (resolved.data) handle = resolved.data;
      } catch {}
      const { data, error } = await sb.auth.signInWithPassword({ email: emailFor(handle), password });
      guard(error);
      leaving = false;
      uid = data.user.id;
      if (data.session) keepSession(data.session);
      const user = await profileById(uid);
      if (user.bannedUntil > Date.now()) {
        leaving = true;
        await sb.auth.signOut({ scope: 'local' });
        dropKeptSession();
        throw new Error('Аккаунт заблокирован');
      }
      keepProfile(user); 
      listen();
      return { user };
    },

    async logout() {
      leaving = true;
      
      
      
      try {
        await sb.auth.signOut({ scope: 'local' });
      } catch {
        await sb.auth.signOut().catch(() => {});
      }
      uid = null;
      dropKeptSession();
      try {
        localStorage.removeItem(KEEP_KEY);
      } catch {}
      if (channel) {
        sb.removeChannel(channel);
        channel = null;
      }
      return { ok: true };
    },

    cachedUser() {
      const kept = keptProfile();
      return kept && (!uid || kept.id === uid) ? kept : null;
    },

    
    
    sessionGone() {
      return sessionLost && !uid;
    },

    async me() {
      if (!uid && !leaving) {
        const restored = await restoreSession(2);
      }
      if (!uid) {
        return { user: null };
      }
      if (Date.now() - lastSuccessTime > 25 * 60 * 1000) {
        await restoreSession(2).catch(() => {});
      }
      try { await sb.rpc('touch_presence'); } catch {}
      try { await sb.rpc('touch_streak'); } catch {}
      try {
        const user = await profileById(uid);
        if (user) keepProfile(user);
        return { user };
      } catch (error) {
        const kept = keptProfile();
        if (kept && kept.id === uid) return { user: kept };
        throw error;
      }
    },

    async tidyProfile() {
      if (!uid) return { moved: 0 };
      const { data } = await sb.from('profiles').select('avatar, banner, pins, status_icon').eq('id', uid).maybeSingle();
      if (!data) return { moved: 0 };
      const heavy = (value) => typeof value === 'string' && value.startsWith('data:') && value.length >= 24000;
      const fields = {};
      let moved = 0;
      if (heavy(data.avatar)) {
        fields.avatar = await lighten(data.avatar, 'avatar');
        if (fields.avatar !== data.avatar) moved += 1;
      }
      if (heavy(data.banner)) {
        fields.banner = await lighten(data.banner, 'banner');
        if (fields.banner !== data.banner) moved += 1;
      }
      if (heavy(data.status_icon)) {
        fields.status_icon = await lighten(data.status_icon, 'status');
        if (fields.status_icon !== data.status_icon) moved += 1;
      }
      const pins = normalizePins(data.pins);
      if (pins.some((pin) => heavy(pin.image))) {
        for (const pin of pins) pin.image = await lighten(pin.image, 'pin');
        fields.pins = pins;
        moved += 1;
      }
      if (!moved) return { moved: 0 };
      await sb.from('profiles').update(fields).eq('id', uid);
      return { moved };
    },

    async updateMe(patch) {
      const id = requireUid();
      const fields = {};
      if (patch.displayName != null) fields.display_name = String(patch.displayName).slice(0, 40);
      if (patch.bio != null) fields.bio = String(patch.bio).slice(0, 300);
      if (patch.hue != null) fields.hue = Number(patch.hue);
      if (patch.mood != null) fields.mood = patch.mood;
      if (patch.theme != null) fields.theme = patch.theme;
      if (patch.accent != null) fields.accent = patch.accent;
      if (patch.avatar !== undefined) fields.avatar = await lighten(patch.avatar, 'avatar');
      if (patch.pins !== undefined) {
        const pins = normalizePins(patch.pins);
        for (const pin of pins) pin.image = await lighten(pin.image, 'pin');
        fields.pins = pins;
      }
      if (patch.banner !== undefined) fields.banner = await lighten(patch.banner, 'banner');
      if (patch.dayWord !== undefined) {
        fields.day_word = patch.dayWord;
        fields.day_word_at = new Date().toISOString();
      }
      if (patch.shareWord !== undefined) fields.share_word = !!patch.shareWord;
      if (patch.notifyPosts !== undefined) fields.notify_posts = !!patch.notifyPosts;
      if (patch.statusIcon !== undefined) fields.status_icon = await lighten(patch.statusIcon, 'status');
      const { error } = await sb.from('profiles').update(fields).eq('id', id);
      guard(error);
      return { user: await profileById(id) };
    },

    async changePassword({ current, next }) {
      const id = requireUid();
      const profile = await profileById(id);
      const check = await sb.auth.signInWithPassword({ email: emailFor(profile.login_name || profile.username), password: current });
      if (check.error) throw new Error('Текущий пароль неверный');
      const { error } = await sb.auth.updateUser({ password: next });
      guard(error);
      return { ok: true };
    },

    async sessions() {
      const { data } = await sb.auth.getSession();
      const session = data?.session;
      if (!session) return { sessions: [] };
      return {
        sessions: [
          {
            id: 'current',
            agent: navigator.userAgent,
            createdAt: Date.now(),
            lastSeen: Date.now(),
            current: true
          }
        ]
      };
    },

    async dropSession() {
      
      try {
        await sb.auth.signOut({ scope: 'others' });
      } catch {
        return { ok: false };
      }
      return { ok: true };
    },

    async searchUsers(query) {
      const q = String(query || '').replace(/^@/, '').replace(/[%_]/g, '');
      let request = sb.from('profiles').select('*').order('last_seen', { ascending: false }).limit(40);
      if (q) request = request.or(`username.ilike.%${q}%,display_name.ilike.%${q}%,bio.ilike.%${q}%`);
      const { data, error } = await request;
      guard(error);
      const found = new Map((data || []).map((row) => [row.id, row]));
      if (q) {
        try {
          const aliases = await sb.from('usernames').select('user_id').ilike('username', `%${q}%`).limit(40);
          const missing = (aliases.data || []).map((row) => row.user_id).filter((id) => !found.has(id));
          if (missing.length) {
            const extra = await sb.from('profiles').select('*').in('id', missing);
            for (const row of extra.data || []) found.set(row.id, row);
          }
        } catch {}
      }
      return { users: [...found.values()].map((row) => shapeProfile(row)) };
    },

    async saveSession() {
      const { data } = await sb.auth.getSession();
      if (!data?.session) return null;
      keepSession(data.session);
      return {
        access_token: data.session.access_token,
        refresh_token: data.session.refresh_token
      };
    },

    async useSession(tokens) {
      if (!tokens?.refresh_token) throw new Error('Сессия не сохранена, войдите заново');
      const { data, error } = await sb.auth.setSession({
        access_token: tokens.access_token || '',
        refresh_token: tokens.refresh_token
      });
      guard(error);
      leaving = false;
      uid = data?.user?.id || data?.session?.user?.id || null;
      if (!uid) throw new Error('Сессия устарела, войдите заново');
      if (data?.session) keepSession(data.session);
      sessionLost = false;
      listen();
      const user = await profileById(uid);
      if (user?.bannedUntil > Date.now()) {
        leaving = true;
        await sb.auth.signOut({ scope: 'local' }).catch(() => {});
        dropKeptSession();
        uid = null;
        throw new Error('Аккаунт заблокирован');
      }
      return { user };
    },

    async notifications(limit = 40) {
      const me = requireUid();
      const { data, error } = await sb
        .from('notifications')
        .select('*')
        .eq('user_id', me)
        .order('created_at', { ascending: false })
        .limit(limit);
      if (error) return { items: [], unread: 0 };
      const items = (data || []).map((row) => ({
        id: row.id,
        kind: row.kind,
        title: row.title || '',
        body: row.body || '',
        meta: row.meta || {},
        createdAt: ms(row.created_at),
        read: !!row.read_at
      }));
      return { items, unread: items.filter((row) => !row.read).length };
    },

    async unreadNotifications() {
      if (!uid) return { count: 0 };
      const { count, error } = await sb
        .from('notifications')
        .select('id', { count: 'exact', head: true })
        .eq('user_id', uid)
        .is('read_at', null);
      if (error) return { count: 0 };
      return { count: count || 0 };
    },

    async readNotifications(ids) {
      await sb.rpc('mark_notifications', { ids: ids && ids.length ? ids : null });
      return { ok: true };
    },

    async clearNotifications() {
      await sb.rpc('clear_notifications');
      return { ok: true };
    },

    async linkCode() {
      requireUid();
      const { data, error } = await sb.rpc('make_link_code');
      guard(error);
      return { code: data };
    },

    async billing() {
      requireUid();
      const { data, error } = await sb.rpc('my_billing');
      if (error) return { telegram: null, payments: [] };
      return data || { telegram: null, payments: [] };
    },

    async myUsernames() {
      const me = requireUid();
      const { data, error } = await sb
        .from('usernames')
        .select('username, created_at')
        .eq('user_id', me)
        .order('created_at', { ascending: true });
      if (error) return { names: [], limit: 3 };
      const limit = await sb.rpc('username_limit');
      return { names: (data || []).map((row) => row.username), limit: limit.data || 3 };
    },

    async addUsername(name) {
      const { data, error } = await sb.rpc('add_username', { wanted: name });
      guard(error);
      return { username: data };
    },

    async dropUsername(name) {
      const { error } = await sb.rpc('drop_username', { target: name });
      guard(error);
      return { ok: true };
    },

    async setMainUsername(name) {
      const { error } = await sb.rpc('set_main_username', { target: name });
      guard(error);
      return { user: await profileById(uid) };
    },

    async getUser(name) {
      const clean = String(name).toLowerCase().replace(/^@/, '');
      let { data, error } = await sb.from('profiles').select('*').eq('username', clean).maybeSingle();
      guard(error);
      if (!data) {
        const alias = await sb.from('usernames').select('user_id').eq('username', clean).maybeSingle();
        if (alias.data) {
          const found = await sb.from('profiles').select('*').eq('id', alias.data.user_id).maybeSingle();
          data = found.data;
        }
      }
      if (!data) throw new Error('Пользователь не найден');
      const grab = () =>
        sb
          .from('posts')
          .select(POST_SELECT())
          .eq('author_id', data.id)
          .eq('removed', false)
          .order('created_at', { ascending: false })
          .limit(50);
      let posts = await grab();
      if (missingColumn(posts.error) && dropTier()) {
        posts = await grab();
      }
      guard(posts.error);
      const liked = await likedSet((posts.data || []).map((row) => row.id));
      return {
        user: shapeProfile(data, await counters(data.id)),
        posts: (posts.data || []).map((row) => shapePost(row, liked))
      };
    },

    async listPosts({ mood, kind, before, limit, includeRemoved, ids } = {}) {
      const size = Math.min(40, Math.max(4, Number(limit) || 12));
      const picked = Array.isArray(ids) ? ids.filter((value) => value !== null && value !== undefined) : null;
      if (picked && !picked.length) return { posts: [], more: false, cursor: null };
      const build = () => {
        let request = sb.from('posts').select(POST_SELECT());
        if (!includeRemoved) request = request.eq('removed', false);
        request = request.eq('is_draft', false);
        if (picked) return request.in('id', picked).limit(picked.length);
        request = request.order('created_at', { ascending: false }).limit(size);
        if (later) request = request.lte('publish_at', new Date().toISOString());
        if (mood) request = request.eq('mood', mood);
        if (!legacyPosts && kind === 'reels') request = request.in('kind', ['video', 'album']);
        if (!legacyPosts && kind === 'video') request = request.eq('kind', 'video');
        if (!legacyPosts && kind === 'album') request = request.eq('kind', 'album');
        if (!legacyPosts && kind === 'feed') request = request.eq('kind', 'text');
        if (before) request = request.lt('created_at', new Date(Number(before)).toISOString());
        return request;
      };
      let { data, error } = await build();
      if (missingColumn(error) && later) {
        later = false;
        ({ data, error } = await build());
      }
      while (missingColumn(error) && dropTier()) {
        if (legacyPosts && (kind === 'video' || kind === 'album' || kind === 'reels')) return { posts: [], more: false, cursor: null };
        ({ data, error } = await build());
      }
      guard(error);
      const liked = await likedSet((data || []).map((row) => row.id));
      const origins = postTier === 0 ? await withOrigins(data || []) : new Map();
      const posts = (data || []).map((row) => shapePost(row, liked, { origin: origins.get(row.repost_of) || null }));
      if (picked) {
        const order = new Map(picked.map((value, index) => [String(value), index]));
        posts.sort((a, b) => (order.get(String(a.id)) ?? 0) - (order.get(String(b.id)) ?? 0));
        return { posts, more: false, cursor: null };
      }
      return { posts, more: posts.length === size, cursor: posts.length ? posts[posts.length - 1].createdAt : null };
    },

    async listAnnouncements() {
      const { data, error } = await sb
        .from('announcements')
        .select('*')
        .gt('until', new Date().toISOString())
        .order('created_at', { ascending: false })
        .limit(4);
      if (error) return { announcements: [] };
      return {
        announcements: (data || []).map((row) => ({
          id: row.id,
          title: row.title || '',
          body: row.body || '',
          tone: row.tone || 'info',
          createdAt: ms(row.created_at),
          until: ms(row.until)
        }))
      };
    },

    async createAnnouncement({ title, body, tone, days }) {
      const me = requireUid();
      const until = new Date(Date.now() + Math.max(1, Number(days) || 7) * 86400000).toISOString();
      const { error } = await sb.from('announcements').insert({
        title: String(title || '').slice(0, 80),
        body: String(body || '').slice(0, 600),
        tone: tone || 'info',
        author_id: me,
        until
      });
      guard(error);
      return { ok: true };
    },

    async deleteAnnouncement(id) {
      const { error } = await sb.from('announcements').delete().eq('id', id);
      guard(error);
      return { ok: true };
    },

    async bumpViews(id) {
      await sb.rpc('bump_post_views', { target: id });
      return { ok: true };
    },

    async uploadMedia(dataUrl, hint = 'jpg') {
      requireUid();
      const response = await fetch(dataUrl);
      const blob = await response.blob();
      const known = /^(video|image)\//.test(blob.type || '') ? blob.type.split(';')[0] : '';
      const type = known || (hint === 'mp4' ? 'video/mp4' : 'image/jpeg');
      const ext = (type.split('/')[1] || hint).replace('quicktime', 'mov');
      const path = `${uid}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
      const upload = await sb.storage.from('media').upload(path, blob, { contentType: type, upsert: false });
      if (upload.error) {
        if (/bucket/i.test(upload.error.message)) throw new Error('В базе данных нет хранилища media. Прогоните schema.sql заново');
        guard(upload.error);
      }
      const { data } = sb.storage.from('media').getPublicUrl(path);
      return data.publicUrl;
    },

    async createPost({ text, image, mood, kind, media, video, poster, duration, sound, poll, publishAt, isDraft }) {
      const id = requireUid();
      const body = String(text || '').trim().slice(0, 5000);
      const album = Array.isArray(media) ? media.filter(Boolean).slice(0, 10) : [];
      if (!body && !image && !album.length && !video && !poll && !sound) throw new Error('Пустой пост');
      const payload = {
        author_id: id,
        body,
        image: image || album[0] || poster || null,
        mood: mood || 'calm',
        kind: kind || (video ? 'video' : album.length > 1 ? 'album' : 'text'),
        media: album,
        video: video || null,
        poster: poster || null,
        duration: Math.max(0, Math.round(Number(duration) || 0)),
        sound: sound || null,
        poll: poll || null
      };
      if (publishAt && publishAt > Date.now()) payload.publish_at = new Date(publishAt).toISOString();
      if (isDraft) payload.is_draft = true;
      const shed = [['publish_at'], ['sound', 'poll'], ['kind', 'media', 'video', 'poster', 'duration']];
      let { data, error } = await sb.from('posts').insert(payload).select(POST_SELECT()).single();
      for (const keys of shed) {
        if (!missingColumn(error)) break;
        dropTier();
        keys.forEach((key) => delete payload[key]);
        if (!payload.kind && (video || album.length > 1)) {
          throw new Error('Видео и альбомы появятся после того, как вы прогоните supabase/schema.sql заново');
        }
        ({ data, error } = await sb.from('posts').insert(payload).select(POST_SELECT()).single());
      }
      guard(error);
      try { await sb.rpc('bump_daily_quest', { p_quest_key: 'post', p_amount: 1 }); await sb.rpc('add_xp', { p_amount: 15 }); } catch {}
      return { post: shapePost(data, new Set()) };
    },

    async deletePost(id) {
      const { error } = await sb.from('posts').delete().eq('id', id);
      guard(error);
      return { ok: true };
    },

    async toggleLike(id) {
      const me = requireUid();
      const existing = await sb.from('likes').select('post_id').eq('post_id', id).eq('user_id', me).maybeSingle();
      if (existing.data) {
        const { error } = await sb.from('likes').delete().eq('post_id', id).eq('user_id', me);
        guard(error);
      } else {
        const { error } = await sb.from('likes').insert({ post_id: id, user_id: me });
        guard(error);
      }
      const { data, error } = await sb.from('posts').select(POST_SELECT()).eq('id', id).single();
      guard(error);
      return { post: shapePost(data, await likedSet([id])) };
    },

    async listComments(id) {
      const grab = (columns) =>
        sb.from('comments').select(columns).eq('post_id', id).order('id', { ascending: true }).limit(200);
      let { data, error } = await grab(`id, body, created_at, removed, removed_reason, removed_auto, reply_to_id, reply_to_user, author:profiles!comments_author_id_fkey(${AUTHOR_FIELDS}), replyTo:profiles!comments_reply_to_user_fkey(username, display_name)`);
      if (missingColumn(error)) {
        ({ data, error } = await grab(`id, body, created_at, removed, removed_reason, removed_auto, author:profiles!comments_author_id_fkey(${AUTHOR_FIELDS})`));
      }
      guard(error);
      return {
        comments: (data || []).map((row) => ({
          id: row.id,
          text: row.body,
          createdAt: ms(row.created_at),
          removed: !!row.removed,
          removedReason: row.removed_reason || '',
          removedAuto: !!row.removed_auto,
          author: shapeProfile(row.author),
          replyToId: row.reply_to_id || null,
          replyToUsername: row.replyTo?.username || null
        }))
      };
    },

    async addComment(id, text, replyTo) {
      const me = requireUid();
      const body = String(text || '').trim().slice(0, 500);
      if (!body) throw new Error('Пустой комментарий');
      const recent = await sb
        .from('comments')
        .select('id')
        .eq('post_id', id)
        .eq('author_id', me)
        .eq('body', body)
        .gt('created_at', new Date(Date.now() - 10000).toISOString())
        .limit(1);
      if (!recent.data?.length) {
        const payload = { post_id: id, author_id: me, body };
        if (replyTo && typeof replyTo === 'object') {
          if (replyTo.commentId) payload.reply_to_id = replyTo.commentId;
          if (replyTo.userId) payload.reply_to_user = replyTo.userId;
        }
        const { error } = await sb.from('comments').insert(payload);
        guard(error);
        try { await sb.rpc('bump_daily_quest', { p_quest_key: 'comment', p_amount: 1 }); await sb.rpc('add_xp', { p_amount: 5 }); } catch {}
      }
      const { data } = await sb.from('posts').select(POST_SELECT()).eq('id', id).single();
      return { post: shapePost(data, await likedSet([id])) };
    },

    async contacts() {
      const me = requireUid();
      const { data, error } = await sb
        .from('contacts')
        .select('contact:profiles!contacts_contact_id_fkey(*)')
        .eq('user_id', me);
      guard(error);
      return { contacts: (data || []).map((row) => shapeProfile(row.contact)).filter(Boolean) };
    },

    async addContact(id) {
      const me = requireUid();
      if (id === me) throw new Error('Нельзя добавить себя');
      const { error } = await sb.from('contacts').upsert({ user_id: me, contact_id: id });
      guard(error);
      return { ok: true };
    },

    async removeContact(id) {
      const me = requireUid();
      const { error } = await sb.from('contacts').delete().eq('user_id', me).eq('contact_id', id);
      guard(error);
      return { ok: true };
    },

    async chats() {
      const me = requireUid();
      const memberships = await sb.from('chat_members').select('chat_id, role, read_at').eq('user_id', me);
      guard(memberships.error);
      const ids = (memberships.data || []).map((row) => row.chat_id);
      if (!ids.length) return { chats: [] };

      const [chatRows, memberRows, messageRows] = await Promise.all([
        sb.from('chats').select('*').in('id', ids),
        sb.from('chat_members').select('chat_id, role, user_id, read_at, profile:profiles!chat_members_user_id_fkey(*)').in('chat_id', ids),
        sb.from('messages').select('*').in('chat_id', ids).eq('removed', false).order('id', { ascending: false }).limit(400)
      ]);
      guard(chatRows.error || memberRows.error || messageRows.error);

      const authors = new Map();
      for (const row of memberRows.data || []) if (row.profile) authors.set(row.profile.id, row.profile);

      const chats = (chatRows.data || []).map((chat) => {
        const mine = (memberships.data || []).find((row) => row.chat_id === chat.id);
        const members = (memberRows.data || [])
          .filter((row) => row.chat_id === chat.id && row.profile)
          .map((row) => ({ ...shapeProfile(row.profile), role: row.role }));
        const peer = chat.kind === 'dm' ? members.find((m) => m.id !== me) || members[0] : null;
        const history = (messageRows.data || []).filter((row) => row.chat_id === chat.id);
        const last = history[0];
        const readAt = ms(mine?.read_at);
        const peerReadAt = (memberRows.data || [])
          .filter((row) => row.chat_id === chat.id && row.user_id !== me)
          .reduce((top, row) => Math.max(top, ms(row.read_at)), 0);
        return {
          id: chat.id,
          kind: chat.kind,
          title: chat.kind === 'dm' ? (peer ? peer.displayName : 'Диалог') : chat.title,
          hue: chat.kind === 'dm' && peer ? peer.hue : chat.hue,
          ownerId: chat.owner_id,
          peer,
          role: mine?.role || null,
          peerReadAt,
          members,
          lastMessage: last ? shapeMessage(last, authors) : null,
          unread: history.filter((row) => ms(row.created_at) > readAt && row.author_id !== me).length
        };
      });

      chats.sort((a, b) => (b.lastMessage?.createdAt || 0) - (a.lastMessage?.createdAt || 0));
      return { chats };
    },

    async createChat({ kind, title, members }) {
      const me = requireUid();
      if (kind === 'dm') {
        const peer = (members || [])[0];
        if (!peer) throw new Error('Выберите собеседника');
        const { data, error } = await sb.rpc('open_dm', { peer });
        guard(error);
        const list = await this.chats();
        return { chat: list.chats.find((chat) => chat.id === data) };
      }
      const name = String(title || '').trim();
      if (!name) throw new Error('Нужно название');
      const created = await sb
        .from('chats')
        .insert({ kind, title: name, owner_id: me, hue: 150 + Math.floor(Math.random() * 180) })
        .select('*')
        .single();
      guard(created.error);
      const rows = [{ chat_id: created.data.id, user_id: me, role: 'owner' }];
      for (const id of members || []) if (id !== me) rows.push({ chat_id: created.data.id, user_id: id, role: 'member' });
      const joined = await sb.from('chat_members').insert(rows);
      guard(joined.error);
      const list = await this.chats();
      return { chat: list.chats.find((chat) => chat.id === created.data.id) };
    },

    async addMember(chatId, userId) {
      const { error } = await sb.from('chat_members').insert({ chat_id: chatId, user_id: userId, role: 'member' });
      guard(error);
      const list = await this.chats();
      return { chat: list.chats.find((chat) => chat.id === chatId) };
    },

    async messages(chatId) {
      const { data, error } = await sb
        .from('messages')
        .select(`*, author:profiles!messages_author_id_fkey(${AUTHOR_FIELDS})`)
        .eq('chat_id', chatId)
        .eq('removed', false)
        .order('id', { ascending: true })
        .limit(200);
      guard(error);
      return { messages: (data || []).map((row) => shapeMessage(row)) };
    },

    async sendMessage(chatId, payload) {
      const me = requireUid();
      const msgPayload = {
        chat_id: chatId,
        author_id: me,
        kind: payload.kind || 'text',
        body: String(payload.body || '').slice(0, 4000),
        media: payload.media || null,
        duration: payload.duration || 0
      };
      if (payload.replyToId) msgPayload.reply_to_id = payload.replyToId;
      const { data, error } = await sb
        .from('messages')
        .insert(msgPayload)
        .select(`*, author:profiles!messages_author_id_fkey(${AUTHOR_FIELDS})`)
        .single();
      guard(error);
      try { await sb.rpc('bump_daily_quest', { p_quest_key: 'chat', p_amount: 1 }); await sb.rpc('add_xp', { p_amount: 3 }); } catch {}
      return { message: shapeMessage(data) };
    },

    async markRead(chatId) {
      if (!uid) return { ok: true };
      await sb.from('chat_members').update({ read_at: new Date().toISOString() }).eq('chat_id', chatId).eq('user_id', uid);
      return { ok: true };
    },

    async callSignal(chatId, toId, kind, payload) {
      const me = requireUid();
      const { error } = await sb.from('call_signals').insert({
        chat_id: chatId,
        from_id: me,
        to_id: toId,
        kind,
        payload: payload || {}
      });
      guard(error);
      return { ok: true };
    },

    async callInbox(since) {
      if (!uid) return { signals: [] };
      const { data, error } = await sb
        .from('call_signals')
        .select('*')
        .eq('to_id', uid)
        .gt('id', Number(since) || 0)
        .order('id', { ascending: true })
        .limit(50);
      if (error) return { signals: [] };
      return {
        signals: (data || []).map((row) => ({
          id: row.id,
          chatId: row.chat_id,
          fromId: row.from_id,
          kind: row.kind,
          payload: row.payload || {},
          createdAt: ms(row.created_at)
        }))
      };
    },

    async callClear(chatId) {
      if (!uid) return { ok: true };
      await sb.from('call_signals').delete().eq('chat_id', chatId).or(`to_id.eq.${uid},from_id.eq.${uid}`);
      return { ok: true };
    },

    async wipePosts(userId) {
      const { data, error } = await sb.rpc('admin_wipe_posts', { target: userId });
      guard(error);
      return { removed: data || 0 };
    },

    
    async adminDeleteUser(userId) {
      const { data, error } = await sb.rpc('admin_delete_user', { target: userId });
      if (error && /could not find the function|does not exist/i.test(error.message || '')) {
        throw new Error('В базе ещё нет этой функции. Прогоните на сервере 06-shema.sh и попробуйте снова');
      }
      guard(error);
      return data || { ok: true };
    },

    async resetLook(userId) {
      const { error } = await sb.rpc('admin_reset_look', { target: userId });
      guard(error);
      return { ok: true };
    },

    async renameUser(userId, name) {
      const { error } = await sb.rpc('admin_rename', { target: userId, name });
      guard(error);
      return { ok: true };
    },

    async report({ targetKind, targetId, reason, image }) {
      const me = requireUid();
      const { error } = await sb.from('reports').insert({
        reporter_id: me,
        target_kind: targetKind,
        target_id: String(targetId),
        target_user: targetKind === 'user' ? targetId : null,
        reason: String(reason).slice(0, 600),
        image: image || null
      });
      guard(error);
      return { ok: true };
    },

    async modReports() {
      const { data, error } = await sb
        .from('reports')
        .select('*, reporter:profiles!reports_reporter_id_fkey(*), target:profiles!reports_target_user_fkey(*)')
        .order('id', { ascending: false })
        .limit(100);
      guard(error);
      return {
        reports: (data || []).map((row) => ({
          id: row.id,
          targetKind: row.target_kind,
          targetId: row.target_id,
          reason: row.reason,
          image: row.image,
          status: row.status,
          createdAt: ms(row.created_at),
          reporter: shapeProfile(row.reporter),
          target: shapeProfile(row.target)
        }))
      };
    },

    async closeReport(id, status) {
      const { error } = await sb.rpc('mod_close_report', { target: id, new_status: status || 'closed' });
      guard(error);
      return { ok: true };
    },

    async modQueue() {
      const grab = () => sb.from('posts').select(POST_SELECT()).order('created_at', { ascending: false }).limit(60);
      let { data, error } = await grab();
      if (missingColumn(error) && dropTier()) {
        ({ data, error } = await grab());
      }
      guard(error);
      const liked = await likedSet((data || []).map((row) => row.id));
      return { posts: (data || []).map((row) => shapePost(row, liked)) };
    },

    async removePost(id, reason, proof) {
      const { error } = await sb.rpc('mod_remove_post', { target: id, reason, proof: proof || '' });
      guard(error);
      return { ok: true };
    },

    async punish({ userId, kind, minutes, reason }) {
      const { error } = await sb.rpc('mod_punish', { target: userId, kind, minutes: minutes || 0, reason });
      guard(error);
      return { ok: true };
    },

    async touchDevice(info, fresh) {
      const { data, error } = await sb.rpc('touch_device', {
        fp: info.id,
        info: { label: info.label, platform: info.platform, country: info.country, app: info.app },
        fresh: !!fresh
      });
      guard(error);
      return { state: data || { blocked: false } };
    },

    async deviceState(id) {
      const { data, error } = await sb.rpc('device_ban_state', { fp: id });
      guard(error);
      return { state: data || { blocked: false } };
    },

    async userInfo(id) {
      const { data, error } = await sb.rpc('mod_user_info', { target: id });
      guard(error);
      return { info: data };
    },

    async banDevice(id, minutes, reason) {
      const { data, error } = await sb.rpc('mod_ban_device', { fp: id, minutes: minutes || 0, reason });
      guard(error);
      return data;
    },

    async unbanDevice(id) {
      const { error } = await sb.rpc('mod_unban_device', { fp: id });
      guard(error);
      return { ok: true };
    },

    async modTeam() {
      const { data, error } = await sb.rpc('admin_mod_team');
      guard(error);
      return { team: data || [] };
    },

    async setRank(id, rank) {
      const { data, error } = await sb.rpc('admin_set_rank', { target: id, rank });
      guard(error);
      return data;
    },

    async grantCoins(amount, reason) {
      const { data, error } = await sb.rpc('grant_coins', { amount, reason: reason || '' });
      guard(error);
      return data || { added: 0 };
    },

    async coinLog() {
      const { data, error } = await sb
        .from('coin_log')
        .select('*')
        .eq('user_id', requireUid())
        .order('id', { ascending: false })
        .limit(40);
      guard(error);
      return { rows: (data || []).map((row) => ({ id: row.id, amount: row.amount, reason: row.reason, createdAt: ms(row.created_at) })) };
    },

    async giftTypes() {
      const { data, error } = await sb.from('gift_types').select('*').order('sort');
      guard(error);
      return { types: data || [] };
    },

    async gifts(userId) {
      const { data, error } = await sb
        .from('gifts')
        .select('*, type:gift_types(*), from:profiles!gifts_from_id_fkey(username,display_name,avatar,hue)')
        .eq('owner_id', userId || requireUid())
        .eq('sold', false)
        .order('id', { ascending: false });
      guard(error);
      return {
        gifts: (data || []).map((row) => ({
          id: row.id,
          typeId: row.type_id,
          title: row.type?.title || row.type_id,
          price: row.type?.price || 0,
          rarity: row.type?.rarity || 'common',
          art: row.type?.art || 'spark',
          hue: row.type?.hue ?? 220,
          note: row.note || '',
          pinned: !!row.pinned,
          createdAt: ms(row.created_at),
          from: row.from ? { username: row.from.username, displayName: row.from.display_name, avatar: row.from.avatar, hue: row.from.hue } : null
        }))
      };
    },

    async buyGift(typeId, userId, note) {
      const { data, error } = await sb.rpc('buy_gift', { gift: typeId, target: userId, note: note || '' });
      guard(error);
      return data;
    },

    async sellGift(id) {
      const { data, error } = await sb.rpc('sell_gift', { target: id });
      guard(error);
      return data;
    },

    async pinGift(id, on) {
      const { error } = await sb.rpc('pin_gift', { target: id, on_shelf: !!on });
      guard(error);
      return { ok: true };
    },

    async campfireJoin() {
      const { data, error } = await sb.rpc('campfire_join');
      guard(error);
      return data;
    },

    async campfireSay(room, body) {
      const { error } = await sb.rpc('campfire_say', { room, body });
      guard(error);
      return { ok: true };
    },

    async campfireRead(room, after) {
      const { data, error } = await sb.rpc('campfire_read', { room, after: after || 0 });
      guard(error);
      return data;
    },

    async campfireLeave(room) {
      const { error } = await sb.rpc('campfire_leave', { room });
      guard(error);
      return { ok: true };
    },

    async letterSend(body) {
      const { data, error } = await sb.rpc('letter_send', { body });
      guard(error);
      return data;
    },

    async letterTake() {
      const { data, error } = await sb.rpc('letter_take');
      guard(error);
      return data;
    },

    async letterReply(id, answer) {
      const { error } = await sb.rpc('letter_reply', { target: id, answer });
      guard(error);
      return { ok: true };
    },

    async myLetters() {
      const { data, error } = await sb.rpc('my_letters');
      guard(error);
      return { letters: (data || []).map((row) => ({ ...row, createdAt: ms(row.createdAt), repliedAt: ms(row.repliedAt) })) };
    },

    async capsuleAdd(body, days) {
      const { data, error } = await sb.rpc('capsule_add', { body, days });
      guard(error);
      return data;
    },

    async capsules() {
      const { data, error } = await sb
        .from('capsules')
        .select('*')
        .eq('user_id', requireUid())
        .order('open_at');
      guard(error);
      return {
        capsules: (data || []).map((row) => ({
          id: row.id,
          body: row.body,
          openAt: ms(row.open_at),
          createdAt: ms(row.created_at),
          openedAt: ms(row.opened_at)
        }))
      };
    },

    async capsuleCheck() {
      const { data, error } = await sb.rpc('capsule_check');
      guard(error);
      return data || { ready: 0 };
    },

    async capsuleDrop(id) {
      const { error } = await sb.from('capsules').delete().eq('id', id).eq('user_id', requireUid());
      guard(error);
      return { ok: true };
    },

    async mentorBoard() {
      const { data, error } = await sb.rpc('mentor_board');
      guard(error);
      return data || { students: [], free: [], reviews: [], mentor: null };
    },

    async mentorFeed() {
      const { data, error } = await sb.rpc('mentor_feed');
      guard(error);
      return { rows: data || [] };
    },

    async mentorTake(id) {
      const { error } = await sb.rpc('mentor_take', { student: id });
      guard(error);
      return { ok: true };
    },

    async mentorDrop(id) {
      const { error } = await sb.rpc('mentor_drop', { student: id });
      guard(error);
      return { ok: true };
    },

    async mentorReview(punishmentId, verdict, note) {
      const { error } = await sb.rpc('mentor_review', { target: punishmentId, verdict, note: note || '' });
      guard(error);
      return { ok: true };
    },

    async repost(id, note) {
      const { data, error } = await sb.rpc('repost', { target: id, note: note || '' });
      guard(error);
      return data;
    },

    async sendPost(chatId, postId, note) {
      const { data, error } = await sb.rpc('send_post', { chat: chatId, target: postId, note: note || '' });
      guard(error);
      return data;
    },

    async setBeta(id, on) {
      const { error } = await sb.rpc('admin_set_beta', { target: id, on_beta: !!on });
      guard(error);
      return { ok: true };
    },

    async giveCoins(id, amount) {
      const { data, error } = await sb.rpc('admin_give_coins', { target: id, amount });
      guard(error);
      return data;
    },

    async react(id, kind) {
      const { data, error } = await sb.rpc('react', { target: id, want: kind });
      guard(error);
      return data;
    },

    async reactions(id) {
      const { data, error } = await sb.rpc('post_reactions', { target: id });
      guard(error);
      return data || {};
    },

    async touchStreak() {
      const { data, error } = await sb.rpc('touch_streak');
      guard(error);
      return data || { days: 0 };
    },

    async breatheIn(minutes) {
      const { data, error } = await sb.rpc('breathe_in', { minutes: minutes || 0 });
      guard(error);
      return data || { together: 1 };
    },

    async breatheOut() {
      await sb.rpc('breathe_out');
      return { ok: true };
    },

    async moodMap() {
      const { data, error } = await sb.rpc('mood_map');
      guard(error);
      return { rows: data || [] };
    },

    async badges() {
      const { data, error } = await sb.rpc('my_badges');
      guard(error);
      return { badges: data || [] };
    },

    async pollVote(id, choice) {
      const { data, error } = await sb.rpc('poll_vote', { target: id, choice });
      guard(error);
      return data;
    },

    async pollResult(id) {
      const { data, error } = await sb.rpc('poll_result', { target: id });
      guard(error);
      return data || { total: 0, counts: {}, mine: null };
    },

    async pinPost(id, on) {
      const { error } = await sb.rpc('pin_post', { target: id, on_top: !!on });
      guard(error);
      return { ok: true };
    },

    async follow(id, on) {
      const { data, error } = await sb.rpc('follow', { target: id, on_follow: !!on });
      guard(error);
      return data;
    },

    async followState(id) {
      const { data, error } = await sb.rpc('follow_state', { target: id });
      guard(error);
      return data || { following: false, followers: 0 };
    },

    async thankMod(id, note) {
      const { data, error } = await sb.rpc('thank_mod', { target: id, note: note || '' });
      guard(error);
      return data;
    },

    async modThanks(id) {
      const { data, error } = await sb.rpc('mod_thanks', { target: id });
      guard(error);
      return data || { total: 0, week: 0, mine: false };
    },

    async eventState() {
      const { data, error } = await sb.rpc('event_state');
      guard(error);
      return data || { active: false };
    },

    async eventClaim() {
      const { data, error } = await sb.rpc('event_claim');
      guard(error);
      return data;
    },

    async deleteComment(id, reason) {
      const { data, error } = await sb.rpc('delete_comment', { target: id, reason: reason || null });
      guard(error);
      return data;
    },

    async inviteMine() {
      const { data, error } = await sb.rpc('invite_mine');
      guard(error);
      return data || { code: '', used: 0, taken: false };
    },

    async inviteUse(code) {
      const { data, error } = await sb.rpc('invite_use', { code });
      guard(error);
      return data;
    },

    async noteAbout(id) {
      const { data, error } = await sb.rpc('note_about', { target: id });
      guard(error);
      return { note: data?.note || '', at: data?.at || null };
    },

    async noteSave(id, body) {
      const { data, error } = await sb.rpc('note_save', { target: id, body: body || '' });
      guard(error);
      return data;
    },

    async reminderMake(body, minutes) {
      const { data, error } = await sb.rpc('reminder_make', { body, minutes });
      guard(error);
      return data;
    },

    async reminderDrop(id) {
      const { error } = await sb.rpc('reminder_drop', { target: id });
      guard(error);
      return { ok: true };
    },

    async remindersMine() {
      const { data, error } = await sb.rpc('reminders_mine');
      guard(error);
      return { reminders: data || [] };
    },

    async remindersRing() {
      const { data, error } = await sb.rpc('reminders_ring');
      if (error) return { rang: 0 };
      return data || { rang: 0 };
    },

    async guardQueue(mode = 'all', size = 40) {
      const { data, error } = await sb.rpc('guard_queue', { size, mode });
      guard(error);
      return { hits: data || [] };
    },

    async guardUndo(id) {
      const { error } = await sb.rpc('guard_undo', { target: id });
      guard(error);
      return { ok: true };
    },

    async guardKeep(id) {
      const { error } = await sb.rpc('guard_keep', { target: id });
      guard(error);
      return { ok: true };
    },

    async guardStats() {
      const { data, error } = await sb.rpc('guard_stats');
      guard(error);
      return data || { day: 0, day_hidden: 0, week_hidden: 0, week_undone: 0, miss: 0, top: [] };
    },

    async guardTry(text) {
      const { data, error } = await sb.rpc('guard_try', { src: text || '' });
      guard(error);
      return data || { score: 0, hits: [], notes: [], hide: false };
    },

    async guardWords() {
      const { data, error } = await sb.rpc('guard_words_all');
      guard(error);
      return { words: data || [] };
    },

    async guardWordAdd(word, kind, weight) {
      const { data, error } = await sb.rpc('guard_word_add', { src: word, kind, weight });
      guard(error);
      return data;
    },

    async guardWordDrop(id) {
      const { error } = await sb.rpc('guard_word_drop', { target: id });
      guard(error);
      return { ok: true };
    },

    async guardConfig() {
      const { data, error } = await sb.rpc('guard_config_read');
      guard(error);
      return data || {};
    },

    async guardConfigSave(patch) {
      const { data, error } = await sb.rpc('guard_config_write', { patch });
      guard(error);
      return data || {};
    },

    async moodTwins() {
      const { data, error } = await sb.rpc('mood_twins');
      guard(error);
      return { mood: data?.mood || null, people: data?.people || [] };
    },

    async messageReact(id, glyph) {
      const { data, error } = await sb.rpc('message_react', { target: id, glyph: glyph || '' });
      guard(error);
      return data;
    },

    async chatReactions(chatId) {
      const { data, error } = await sb.rpc('chat_reactions', { room: chatId });
      guard(error);
      return { reactions: data || {} };
    },

    async seasonState() {
      const { data, error } = await sb.rpc('season_state');
      guard(error);
      return data || { season: 'autumn', collected: 0, total: 0 };
    },

    async setShelf(rows) {
      const { error } = await sb.rpc('set_shelf', { rows });
      guard(error);
      return { ok: true };
    },

    async myPunishments() {
      const { data, error } = await sb
        .from('punishments')
        .select('id, kind, minutes, reason, created_at, reverted')
        .eq('user_id', requireUid())
        .order('created_at', { ascending: false })
        .limit(20);
      guard(error);
      return {
        punishments: (data || []).map((row) => ({
          id: row.id,
          kind: row.kind,
          minutes: row.minutes,
          reason: row.reason || '',
          createdAt: ms(row.created_at),
          reverted: !!row.reverted
        }))
      };
    },

    async appealSend(punishmentId, body) {
      const { data, error } = await sb.rpc('appeal_send', { target: punishmentId, body });
      guard(error);
      return data;
    },

    async myAppeals() {
      const { data, error } = await sb.rpc('my_appeals');
      guard(error);
      return { appeals: data || [] };
    },

    async appealQueue() {
      const { data, error } = await sb.rpc('appeal_queue');
      guard(error);
      return { appeals: data || [] };
    },

    async appealJudge(id, verdict, note) {
      const { data, error } = await sb.rpc('appeal_judge', { target: id, verdict, note: note || '' });
      guard(error);
      return data;
    },

    async monthRecap() {
      const { data, error } = await sb.rpc('month_recap');
      guard(error);
      return data || {};
    },

    async recoveryState() {
      const { data, error } = await sb.rpc('recovery_state');
      guard(error);
      return data || { total: 0 };
    },

    async recoveryMake() {
      const { data, error } = await sb.rpc('recovery_make');
      guard(error);
      return { codes: (data && data.codes) || [] };
    },

    async recoverAccount(login, code, password) {
      const { data, error } = await sb.rpc('recovery_use', { login, code, fresh_password: password });
      guard(error);
      const handle = (data && data.login) || login;
      const answer = await sb.auth.signInWithPassword({ email: emailFor(handle), password });
      guard(answer.error);
      uid = answer.data.user.id;
      listen();
      return { user: await profileById(uid) };
    },

    async summerRecap() {
      const { data, error } = await sb.rpc('summer_recap');
      guard(error);
      return data || {};
    },

    async reelIds(size, seen) {
      const { data, error } = await sb.rpc('feed_reels', { size: size || 12, seen: seen || [] });
      guard(error);
      return { ids: data || [] };
    },

    async strikes(userId) {
      const id = userId || requireUid();
      const { data, error } = await sb
        .from('mod_strikes')
        .select('*')
        .eq('moderator_id', id)
        .order('id', { ascending: false });
      guard(error);
      return { strikes: (data || []).map((row) => ({ id: row.id, reason: row.reason, createdAt: ms(row.created_at) })) };
    },

    async adminStats() {
      const { data, error } = await sb.rpc('admin_stats');
      guard(error);
      return { stats: data };
    },

    async adminHealth() {
      const { data, error } = await sb.rpc('admin_health');
      guard(error);
      return { health: data || {} };
    },

    async praisePick() {
      const { data, error } = await sb.rpc('admin_praise_pick');
      guard(error);
      return { who: data && data.id ? data : null };
    },

    async praise(id, note, coins) {
      const { data, error } = await sb.rpc('admin_praise', { target: id, note: note || '', purse: coins || 100 });
      guard(error);
      return data;
    },

    async quietCall(body) {
      const { error } = await sb.rpc('admin_quiet_call', { body: body || '' });
      guard(error);
      return { ok: true };
    },

    async adminUsers(query) {
      const { data, error } = await sb.rpc('admin_users', { search: query || '' });
      guard(error);
      return { users: (data || []).map((row) => shapeProfile(row)) };
    },

    async setFlags(id, flags) {
      const { error } = await sb.rpc('admin_set_flags', { target: id, flags });
      guard(error);
      return { user: await profileById(id) };
    },

    async setState(id, { action, minutes, reason }) {
      const { error } = await sb.rpc('admin_set_state', {
        target: id,
        action,
        minutes: minutes || 0,
        reason: reason || ''
      });
      guard(error);
      return { user: await profileById(id) };
    },

    async grantPremium(id, days, reason) {
      const { data, error } = await sb.rpc('admin_grant_premium', { target: id, days, reason });
      guard(error);
      return { until: ms(data) };
    },

    async revokePremium(id) {
      const { error } = await sb.rpc('admin_revoke_premium', { target: id });
      guard(error);
      return { ok: true };
    },

    async adminActions() {
      const { data, error } = await sb
        .from('punishments')
        .select('*, actor:profiles!punishments_actor_id_fkey(*), target:profiles!punishments_user_id_fkey(*)')
        .order('id', { ascending: false })
        .limit(150);
      guard(error);
      return {
        actions: (data || []).map((row) => ({
          id: row.id,
          kind: row.kind,
          minutes: row.minutes,
          reason: row.reason,
          postId: row.post_id,
          createdAt: ms(row.created_at),
          reverted: row.reverted,
          actor: shapeProfile(row.actor),
          target: shapeProfile(row.target)
        }))
      };
    },

    async revertAction(id, { strike, reason } = {}) {
      const { data, error } = await sb.rpc('admin_revert', {
        target: id,
        strike: !!strike,
        reason: reason || ''
      });
      guard(error);
      return { ok: true, strikes: data };
    },

    async adminAudit() {
      const { data, error } = await sb
        .from('audit')
        .select('*, actor:profiles!audit_actor_id_fkey(*)')
        .order('id', { ascending: false })
        .limit(200);
      guard(error);
      return {
        entries: (data || []).map((row) => ({
          id: row.id,
          action: row.action,
          meta: row.meta,
          createdAt: ms(row.created_at),
          actor: shapeProfile(row.actor)
        }))
      };
    },

    async journalEntry(day) {
      const me = requireUid();
      const { data, error } = await sb
        .from('journal')
        .select('*')
        .eq('user_id', me)
        .eq('day', day)
        .maybeSingle();
      guard(error);
      return { entry: data ? { day: data.day, body: data.body, mood: data.mood, word: data.word } : null };
    },

    async saveJournal({ day, body, mood, word }) {
      const me = requireUid();
      const { error } = await sb
        .from('journal')
        .upsert(
          { user_id: me, day, body: String(body || '').slice(0, 2000), mood, word: word ? String(word).slice(0, 20) : null },
          { onConflict: 'user_id,day' }
        );
      guard(error);
      try { await sb.rpc('bump_daily_quest', { p_quest_key: 'journal', p_amount: 1 }); await sb.rpc('add_xp', { p_amount: 20 }); } catch {}
      return { ok: true };
    },

    async journalHistory() {
      const me = requireUid();
      const { data, error } = await sb
        .from('journal')
        .select('*')
        .eq('user_id', me)
        .order('day', { ascending: false })
        .limit(120);
      guard(error);
      return {
        entries: (data || []).map((row) => ({ day: row.day, body: row.body || '', mood: row.mood, word: row.word }))
      };
    },

    async publishStory(file, caption) {
      const me = requireUid();
      const name = String(file.name || 'story');
      const ext = (name.includes('.') ? name.split('.').pop() : '').toLowerCase() ||
        (file.type.startsWith('video') ? 'mp4' : 'jpg');
      const path = `${me}/${Date.now()}.${ext}`;

      const upload = await sb.storage.from('stories').upload(path, file, {
        contentType: file.type || 'application/octet-stream',
        upsert: false
      });
      if (upload.error) {
        if (/bucket/i.test(upload.error.message)) {
          throw new Error('В базе данных нет хранилища stories. Прогоните schema.sql заново');
        }
        guard(upload.error);
      }

      const { data } = sb.storage.from('stories').getPublicUrl(path);
      const { error } = await sb.from('stories').insert({
        author_id: me,
        kind: file.type.startsWith('video') ? 'video' : 'image',
        media: data.publicUrl,
        storage_path: path,
        caption: String(caption || '').slice(0, 200)
      });
      guard(error);
      return { ok: true };
    },

    async stories() {
      const { data, error } = await sb
        .from('stories')
        .select(`*, author:profiles!stories_author_id_fkey(${AUTHOR_FIELDS})`)
        .gt('expires_at', new Date().toISOString())
        .order('id', { ascending: true });
      guard(error);
      return {
        stories: (data || []).map((row) => ({
          id: row.id,
          kind: row.kind,
          media: row.media,
          caption: row.caption,
          createdAt: ms(row.created_at),
          expiresAt: ms(row.expires_at),
          author: shapeProfile(row.author)
        }))
      };
    },

    async deleteStory(id) {
      const { error } = await sb.from('stories').delete().eq('id', id);
      guard(error);
      return { ok: true };
    },

    async stickers() {
      const me = requireUid();
      const { data, error } = await sb
        .from('stickers')
        .select('*')
        .eq('owner_id', me)
        .order('id', { ascending: false });
      guard(error);
      return { stickers: (data || []).map((row) => ({ id: row.id, image: row.image })) };
    },

    async addSticker(image) {
      const me = requireUid();
      const { error } = await sb.from('stickers').insert({ owner_id: me, image });
      guard(error);
      return { ok: true };
    },

    async removeSticker(id) {
      const { error } = await sb.from('stickers').delete().eq('id', id);
      guard(error);
      return { ok: true };
    },

    async saveScore(game, score) {
      const me = requireUid();
      const { error } = await sb.from('game_scores').insert({ user_id: me, game, score });
      guard(error);
      try { await sb.rpc('bump_daily_quest', { p_quest_key: 'game', p_amount: 1 }); await sb.rpc('add_xp', { p_amount: Math.floor(score / 50) + 2 }); } catch {}
      return { ok: true };
    },

    async leaderboard(game) {
      const { data, error } = await sb
        .from('game_scores')
        .select('score, profile:profiles!game_scores_user_id_fkey(*)')
        .eq('game', game)
        .order('score', { ascending: false })
        .limit(100);
      guard(error);
      const best = new Map();
      for (const row of data || []) {
        if (!row.profile) continue;
        const current = best.get(row.profile.id);
        if (!current || current.score < row.score) best.set(row.profile.id, { ...shapeProfile(row.profile), score: row.score });
      }
      return { leaderboard: [...best.values()].sort((a, b) => b.score - a.score).slice(0, 20) };
    },

    
    async gratitudeAdd(body, anonymous = false) {
      const { data, error } = await sb.rpc('gratitude_add', { p_body: body, p_anonymous: anonymous });
      guard(error);
      return data || { ok: true };
    },

    async gratitudeList(limit = 30, offset = 0) {
      const { data, error } = await sb.rpc('gratitude_list', { p_limit: limit, p_offset: offset });
      guard(error);
      return { entries: data || [] };
    },

    
    async blockUser(targetId) {
      const { data, error } = await sb.rpc('block_user', { p_target: targetId });
      guard(error);
      return data || { ok: true };
    },

    async unblockUser(targetId) {
      const { data, error } = await sb.rpc('unblock_user', { p_target: targetId });
      guard(error);
      return data || { ok: true };
    },

    async myBlocks() {
      const { data, error } = await sb.rpc('my_blocks');
      guard(error);
      return { blocks: data || [] };
    },

    async amIBlocked(targetId) {
      const { data, error } = await sb.rpc('am_i_blocked', { p_target: targetId });
      guard(error);
      return { blocked: !!data };
    },

    
    async saveCustomTheme(theme) {
      const { data, error } = await sb.rpc('save_custom_theme', { p_theme: theme });
      guard(error);
      return data || { ok: true };
    },

    
    async redeemPromo(code) {
      const { data, error } = await sb.rpc('redeem_promo', { p_code: code });
      guard(error);
      return data || { ok: false };
    },

    async adminCreatePromo(payload) {
      const { data, error } = await sb.rpc('admin_create_promo', {
        p_code: payload.code,
        p_reward_type: payload.rewardType,
        p_reward_amount: payload.rewardAmount || 0,
        p_reward_days: payload.rewardDays || 0,
        p_max_uses: payload.maxUses || 0,
        p_expires_at: payload.expiresAt || null
      });
      guard(error);
      return data || { ok: true };
    },

    async adminListPromos() {
      const { data, error } = await sb.rpc('admin_list_promos');
      guard(error);
      return { promos: data || [] };
    },

    async adminTogglePromo(id, disabled) {
      const { data, error } = await sb.rpc('admin_toggle_promo', { p_id: id, p_disabled: disabled });
      guard(error);
      return data || { ok: true };
    },

    async adminDeletePromo(id) {
      const { data, error } = await sb.rpc('admin_delete_promo', { p_id: id });
      guard(error);
      return data || { ok: true };
    },

    
    async deleteMyComment(id) {
      const { data, error } = await sb.rpc('delete_my_comment', { p_id: id });
      guard(error);
      return data || { ok: true };
    },

    async deleteMyMessage(id) {
      const { data, error } = await sb.rpc('delete_my_message', { p_id: id });
      guard(error);
      return data || { ok: true };
    },

    async myDailyQuests() {
      const { data, error } = await sb.rpc('my_daily_quests');
      guard(error);
      return { quests: data || [] };
    },

    async claimDailyQuest(id) {
      const { data, error } = await sb.rpc('claim_daily_quest', { p_id: id });
      guard(error);
      return data || { ok: true };
    },

    async activeTournaments() {
      const { data, error } = await sb.rpc('active_tournaments');
      guard(error);
      return { tournaments: data || [] };
    },

    async tournamentLeaderboard(id) {
      const { data, error } = await sb.rpc('tournament_leaderboard', { p_tour_id: id });
      guard(error);
      return { leaderboard: data || [] };
    },

    async adminCreateTournament(payload) {
      const { data, error } = await sb.rpc('admin_create_tournament', {
        p_game_id: payload.gameId,
        p_title: payload.title,
        p_ends_at: payload.endsAt,
        p_prize_1: payload.prize1 || 500,
        p_prize_2: payload.prize2 || 250,
        p_prize_3: payload.prize3 || 100
      });
      guard(error);
      return data || { ok: true };
    },

    async recordProfileView(userId) {
      try { await sb.rpc('record_profile_view', { p_profile_id: userId }); } catch {}
      return { ok: true };
    },

    async myProfileViewers() {
      const { data, error } = await sb.rpc('my_profile_viewers');
      guard(error);
      return { viewers: data || [] };
    },

    async addConfession(body, mood = 'calm') {
      const { data, error } = await sb.rpc('add_confession', { p_body: body, p_mood: mood });
      guard(error);
      return data || { ok: true };
    },

    async confessionsList(limit = 30, offset = 0) {
      const { data, error } = await sb.rpc('confessions_list', { p_limit: limit, p_offset: offset });
      guard(error);
      return { confessions: data || [] };
    },

    async deleteConfession(id) {
      const { data, error } = await sb.rpc('delete_confession', { p_id: id });
      guard(error);
      return data || { ok: true };
    },

    async addWishlistItem(title, link = null) {
      const { data, error } = await sb.rpc('add_wishlist_item', { p_title: title, p_link: link });
      guard(error);
      return data || { ok: true };
    },

    async removeWishlistItem(id) {
      const { data, error } = await sb.rpc('remove_wishlist_item', { p_id: id });
      guard(error);
      return data || { ok: true };
    },

    async getWishlist(userId) {
      const { data, error } = await sb.rpc('get_wishlist', { p_user_id: userId });
      guard(error);
      return { items: data || [] };
    },

    async todayChallenge() {
      const { data, error } = await sb.rpc('today_challenge');
      guard(error);
      return data || {};
    },

    async completeTodayChallenge() {
      const { data, error } = await sb.rpc('complete_today_challenge');
      guard(error);
      return data || { ok: true };
    },

    async adminSetChallenge(title, description, reward = 50) {
      const { data, error } = await sb.rpc('admin_set_challenge', {
        p_title: title, p_description: description, p_reward: reward
      });
      guard(error);
      return data || { ok: true };
    },

    async myWeeklyQuests() {
      const { data, error } = await sb.rpc('my_weekly_quests');
      guard(error);
      return { quests: data || [] };
    },

    async touchStreak() {
      const { data, error } = await sb.rpc('touch_streak');
      guard(error);
      return data || { ok: true };
    },

    async todayQuote() {
      const { data, error } = await sb.rpc('today_quote');
      guard(error);
      return data || {};
    },

    async myLevel() {
      const { data, error } = await sb.rpc('my_level');
      guard(error);
      return data || {};
    },

    async createGroup(name, description = '', isPrivate = false) {
      const { data, error } = await sb.rpc('create_group', { p_name: name, p_description: description, p_is_private: isPrivate });
      guard(error);
      return data || { ok: true };
    },
    async listGroups() {
      const { data, error } = await sb.rpc('list_groups');
      guard(error);
      return { groups: data || [] };
    },
    async joinGroup(id) {
      const { data, error } = await sb.rpc('join_group', { p_group_id: id });
      guard(error);
      return data || { ok: true };
    },
    async leaveGroup(id) {
      const { data, error } = await sb.rpc('leave_group', { p_group_id: id });
      guard(error);
      return data || { ok: true };
    },
    async pinPost(id) {
      const { data, error } = await sb.rpc('pin_post', { p_post_id: id });
      guard(error);
      return data || { ok: true };
    },
    async sendFriendRequest(targetId) {
      const { data, error } = await sb.rpc('send_friend_request', { p_target: targetId });
      guard(error);
      return data || { ok: true };
    },
    async acceptFriend(requesterId) {
      const { data, error } = await sb.rpc('accept_friend', { p_requester: requesterId });
      guard(error);
      return data || { ok: true };
    },
    async removeFriend(targetId) {
      const { data, error } = await sb.rpc('remove_friend', { p_target: targetId });
      guard(error);
      return data || { ok: true };
    },
    async myFriends() {
      const { data, error } = await sb.rpc('my_friends');
      guard(error);
      return { friends: data || [] };
    },
    async pendingFriendRequests() {
      const { data, error } = await sb.rpc('pending_friend_requests');
      guard(error);
      return { requests: data || [] };
    },
    async spinWheel() {
      const { data, error } = await sb.rpc('spin_wheel');
      guard(error);
      return data || { ok: false };
    },
    async canSpinToday() {
      const { data, error } = await sb.rpc('can_spin_today');
      guard(error);
      return { can: data !== false };
    },
    async activeEvents() {
      const { data, error } = await sb.rpc('active_events');
      guard(error);
      return { events: data || [] };
    },
    async levelLeaderboard() {
      const { data, error } = await sb.rpc('level_leaderboard');
      guard(error);
      return { leaderboard: data || [] };
    },
    async searchAll(query) {
      const { data, error } = await sb.rpc('search_all', { p_query: query });
      guard(error);
      return data || { users: [], posts: [], groups: [] };
    },
    async setPinCode(code) {
      const { data, error } = await sb.rpc('set_pin_code', { p_code: code });
      guard(error);
      return data || { ok: true };
    },
    async disablePinCode() {
      const { data, error } = await sb.rpc('disable_pin_code');
      guard(error);
      return data || { ok: true };
    },

    async activePixelBattle() {
      const { data, error } = await sb.rpc('active_pixel_battle');
      guard(error);
      return data || { active: false };
    },
    async placePixel(battleId, x, y, color) {
      const { data, error } = await sb.rpc('place_pixel', { p_battle_id: battleId, p_x: x, p_y: y, p_color: color });
      guard(error);
      return data || { ok: false };
    },
    async getPixelInfo(battleId, x, y) {
      const { data, error } = await sb.rpc('get_pixel_info', { p_battle_id: battleId, p_x: x, p_y: y });
      guard(error);
      return data || { empty: true };
    },
    async startPixelBattle() {
      const { data, error } = await sb.rpc('start_pixel_battle');
      guard(error);
      return data || { ok: true };
    }
  };
}
