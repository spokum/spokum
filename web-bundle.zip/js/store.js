import { local } from './backend/local.js';
import { createRemote } from './backend/remote.js';

let backend = local;

export const api = new Proxy({}, {
  get(_target, prop) {
    const value = backend[prop];
    return typeof value === 'function' ? value.bind(backend) : value;
  },
  has(_target, prop) {
    return prop in backend;
  }
});

let starting = null;

export async function initBackend() {
  const params = new URLSearchParams(location.search);
  if (window.SPOKUM_FORCE_LOCAL || params.get('local') === '1') return backend.mode;
  const supabaseUrl = window.SPOKUM_SUPABASE_URL || params.get('supabaseUrl') || '';
  const supabaseKey = window.SPOKUM_SUPABASE_KEY || params.get('supabaseKey') || '';
  const apiBase = window.SPOKUM_API || params.get('api') || '';

  if (supabaseUrl && supabaseKey) {
    if (backend.mode === 'supabase') return backend.mode;
    
    
    if (starting) return starting;
    starting = (async () => {
      try {
        const { createSupabase } = await import('./backend/supabase.js');
        const made = await createSupabase(supabaseUrl, supabaseKey);
        if (backend.mode !== 'supabase') backend = made;
        return backend.mode;
      } catch (error) {
        console.error(error);
        return backend.mode;
      } finally {
        starting = null;
      }
    })();
    return starting;
  }

  if (apiBase) backend = createRemote(apiBase);
  return backend.mode;
}

const memo = new Map();

export async function cached(key, ttl, make) {
  const now = Date.now();
  const hit = memo.get(key);
  if (hit && now - hit.at < ttl) return hit.value;
  const value = await make();
  memo.set(key, { at: now, value });
  return value;
}

export function forget(key) {
  if (key) memo.delete(key);
  else memo.clear();
}

export function isBeta(user) {
  const who = user || state.user;
  return !!(who && (who.isBeta || who.username === 'silver'));
}

export const RANKS = ['Стажёр', 'Младший модератор', 'Модератор', 'Старший модератор', 'Ведущий модератор', 'Начальник модераторов'];

export function rankName(user) {
  if (!user) return '';
  if (user.isAdmin && !user.modRank) return 'Администратор';
  return RANKS[Math.min(Math.max(user.modRank || 0, 0), RANKS.length - 1)];
}

export const state = {
  user: null,
  moodFilter: null,
  tab: 'feed',
  unread: 0,
  online: navigator.onLine,
  quiet: false
};

const FEED_CACHE = 'spokum.cache.feed';

export function cacheFeed(posts) {
  try {
    const trimmed = posts.slice(0, 20).map((post, index) => ({
      ...post,
      image: index < 6 ? post.image : null
    }));
    localStorage.setItem(FEED_CACHE, JSON.stringify({ savedAt: Date.now(), posts: trimmed }));
  } catch {}
}

export function readFeedCache() {
  try {
    const raw = localStorage.getItem(FEED_CACHE);
    if (!raw) return null;
    const data = JSON.parse(raw);
    return Array.isArray(data.posts) && data.posts.length ? data : null;
  } catch {
    return null;
  }
}

export function isPremium(user) {
  return !!(user && user.premiumUntil && user.premiumUntil > Date.now());
}

export const PREMIUM_THEMES = ['aurora', 'sunset', 'royal', 'abyss', 'ink', 'rose', 'gold', 'pearl', 'emerald', 'nebula', 'plum', 'copper', 'sakura', 'mine'];
export const PREMIUM_ACCENTS = ['gold', 'rose', 'ice'];

export const PREMIUM_PERKS = [
  ['crown', 'Значок премиума', 'Корона рядом с ником во всей сети'],
  ['play', 'Истории', 'Видео и фото на 24 часа, открываются по аватару'],
  ['star', 'Свои стикеры', 'Загружайте картинки и шлите их в чатах'],
  ['image', 'Пины', 'Четыре картинки по углам вашего аватара'],
  ['smile', 'Статус у ника', 'Своя маленькая картинка рядом с именем'],
  ['palette', 'Закрытые темы', 'Аврора, Закат, Королевская и Бездна'],
  ['spark', 'Особые акценты', 'Золото, роза и лёд в интерфейсе'],
  ['profile', 'Свечение аватара', 'Мягкая подсветка вокруг фото профиля'],
  ['feed', 'Длинные записи', 'До 5000 символов в посте вместо 2000'],
  ['eye', 'Фото без потерь', 'Снимки грузятся в максимальном качестве'],
  ['key', 'Больше юзернеймов', 'До восьми имён на аккаунт вместо трёх'],
  ['play', 'Премиум игры', 'Небесный каньон и Шарик открыты только по подписке']
];

export function isOffline() {
  return !navigator.onLine;
}

export function requireOnline() {
  if (!navigator.onLine) throw new Error('Нет интернета. Действие станет доступно, когда связь вернётся');
}

const listeners = new Set();

export function subscribe(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

export function emit(event, payload) {
  for (const fn of listeners) fn(event, payload);
}

export function setUser(user) {
  state.user = user;
  applyAppearance(user);
  emit('user', user);
}

const MINE_KEY = 'spokum.theme.mine';

export function myTheme() {
  try {
    const saved = JSON.parse(localStorage.getItem(MINE_KEY));
    if (saved && typeof saved.hue === 'number') return saved;
  } catch {}
  return { dark: true, hue: 210, tint: 14, accent: '#87b7a3' };
}

export function saveMyTheme(patch) {
  const next = { ...myTheme(), ...patch };
  localStorage.setItem(MINE_KEY, JSON.stringify(next));
  paintMyTheme();
  return next;
}

export function paintMyTheme() {
  const mine = myTheme();
  let tag = document.getElementById('spokum-mine');
  if (!tag) {
    tag = document.createElement('style');
    tag.id = 'spokum-mine';
    document.head.appendChild(tag);
  }
  const hue = mine.hue;
  const tint = Math.max(0, Math.min(40, mine.tint ?? 14));
  const ink = mine.dark
    ? {
        bg: `hsl(${hue} ${tint}% 7%)`,
        bg2: `hsl(${hue} ${tint}% 11%)`,
        surface: 'rgba(255,255,255,.04)',
        surface2: 'rgba(255,255,255,.07)',
        line: 'rgba(255,255,255,.08)',
        lineStrong: 'rgba(255,255,255,.15)',
        text: `hsl(${hue} 18% 90%)`,
        muted: `hsl(${hue} 12% 60%)`,
        shadow: '0 16px 40px rgba(0,0,0,.5)',
        glow: '.55'
      }
    : {
        bg: `hsl(${hue} ${Math.min(30, tint + 8)}% 95%)`,
        bg2: `hsl(${hue} ${Math.min(30, tint + 8)}% 99%)`,
        surface: 'rgba(20,25,35,.035)',
        surface2: 'rgba(20,25,35,.06)',
        line: 'rgba(20,25,35,.1)',
        lineStrong: 'rgba(20,25,35,.17)',
        text: `hsl(${hue} 22% 16%)`,
        muted: `hsl(${hue} 12% 44%)`,
        shadow: '0 14px 34px rgba(40,50,70,.1)',
        glow: '.7'
      };
  tag.textContent = `[data-theme='mine']{--bg:${ink.bg};--bg-2:${ink.bg2};--surface:${ink.surface};--surface-2:${ink.surface2};--line:${ink.line};--line-strong:${ink.lineStrong};--text:${ink.text};--muted:${ink.muted};--shadow:${ink.shadow};--glow-1:${mine.accent}1f;--glow-2:${mine.accent}14;--glow:${ink.glow};}
[data-theme='mine'][data-accent]{--accent:${mine.accent};--accent-soft:${mine.accent}2b;--accent-ink:${mine.dark ? '#08110e' : '#ffffff'};}`;
}

export function applyAppearance(user) {
  const root = document.documentElement;
  let theme = user?.theme || localStorage.getItem('spokum.theme') || 'calm';
  let accent = user?.accent || localStorage.getItem('spokum.accent') || 'mint';
  const premium = user ? isPremium(user) : localStorage.getItem('spokum.premium') === '1';
  const patch = {};
  if (!premium) {
    if (PREMIUM_THEMES.includes(theme)) {
      theme = 'calm';
      patch.theme = theme;
    }
    if (PREMIUM_ACCENTS.includes(accent)) {
      accent = 'mint';
      patch.accent = accent;
    }
  }
  if (theme === 'mine') paintMyTheme();
  root.dataset.theme = theme;
  root.dataset.accent = accent;
  const skin = localStorage.getItem('spokum.skin') || 'classic';
  if (skin === 'soft') root.dataset.skin = 'soft';
  else delete root.dataset.skin;
  localStorage.setItem('spokum.theme', theme);
  localStorage.setItem('spokum.accent', accent);
  localStorage.setItem('spokum.premium', premium ? '1' : '0');
  if (user && Object.keys(patch).length) {
    Object.assign(user, patch);
    api.updateMe(patch).catch(() => {});
  }
}

export function setSkin(name) {
  const skin = name === 'soft' ? 'soft' : 'classic';
  localStorage.setItem('spokum.skin', skin);
  if (skin === 'soft') document.documentElement.dataset.skin = 'soft';
  else delete document.documentElement.dataset.skin;
  return skin;
}

export function currentSkin() {
  return localStorage.getItem('spokum.skin') === 'soft' ? 'soft' : 'classic';
}

export const MOODS = {
  calm:     { label: 'Спокойствие', color: 'rgba(127,179,160,.14)', ink: '#7fb3a0' },
  joy:      { label: 'Радость',     color: 'rgba(204,176,121,.15)', ink: '#ccb079' },
  sad:      { label: 'Грусть',      color: 'rgba(138,171,199,.15)', ink: '#8aabc7' },
  anger:    { label: 'Злость',      color: 'rgba(197,130,121,.15)', ink: '#c58279' },
  anxiety:  { label: 'Тревога',     color: 'rgba(159,150,194,.15)', ink: '#9f96c2' },
  tired:    { label: 'Усталость',   color: 'rgba(152,160,173,.15)', ink: '#98a0ad' },
  love:     { label: 'Нежность',    color: 'rgba(199,143,164,.15)', ink: '#c78fa4' },
  inspired: { label: 'Подъём',      color: 'rgba(147,185,141,.15)', ink: '#93b98d' }
};

export function moodStyle(mood) {
  const item = MOODS[mood] || MOODS.calm;
  return `--mood-color:${item.color};--mood-ink:${item.ink}`;
}
