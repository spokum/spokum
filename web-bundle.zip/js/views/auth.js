import { api, setUser } from '../store.js';
import { el, esc, initials } from '../util.js';
import { icon, logoMark } from '../icons.js';
import { toast, pickImage, openSheet } from '../ui.js';

async function openRecovery(login, done) {
  if (!api.recoverAccount) return toast('Восстановление появится, когда база будет обновлена', 'err');
  const body = el(`<div class="col">
    <p class="small" style="margin:0;line-height:1.55">Введите юзернейм, один из кодов восстановления и новый пароль. Код сработает один раз.</p>
    <input class="input" data-who placeholder="Юзернейм" value="${esc(login || '')}" autocomplete="username">
    <input class="input" data-code placeholder="Код вида ABCD-EFGH-IJKL" autocomplete="one-time-code">
    <input class="input" type="password" data-fresh placeholder="Новый пароль" autocomplete="new-password">
    <button class="btn btn-primary" data-go>${icon('key', 17)} Войти по коду</button>
    <p class="tiny muted" style="margin:0;line-height:1.5">Коды создаются заранее в настройках, раздел Безопасность. Если кодов нет и пароль забыт, помочь может только администрация.</p>
  </div>`);
  const sheet = openSheet('Вход по коду', body);
  const go = body.querySelector('[data-go]');
  go.onclick = async () => {
    const who = body.querySelector('[data-who]').value.trim();
    const code = body.querySelector('[data-code]').value.trim();
    const fresh = body.querySelector('[data-fresh]').value;
    if (!who || !code) return toast('Впишите юзернейм и код', 'err');
    if (fresh.length < 8) return toast('Новый пароль минимум 8 символов', 'err');
    go.disabled = true;
    go.textContent = 'Проверяем';
    try {
      const { user } = await api.recoverAccount(who, code, fresh);
      setUser(user);
      sheet.close();
      toast('Пароль сменён, вы вошли');
      done?.();
    } catch (error) {
      go.disabled = false;
      go.innerHTML = `${icon('key', 17)} Войти по коду`;
      toast(error.message, 'err');
    }
  };
}

function humanError(message) {
  const text = String(message || '');
  if (/failed to fetch|networkerror|load failed|network request failed/i.test(text)) return 'не отвечает';
  if (/abort|timeout|timed out/i.test(text)) return 'слишком долго не отвечает';
  return text;
}

async function probe(label, run) {
  const started = Date.now();
  const spent = () => `${((Date.now() - started) / 1000).toFixed(1)} с`;
  try {
    return { label, ok: true, detail: `${await run()} · ${spent()}` };
  } catch (error) {
    return { label, ok: false, detail: `${humanError(error.message)} · ${spent()}` };
  }
}

export async function runDiagnostics() {
  const { openSheet } = await import('../ui.js?v=20251018');
  const body = el('<div class="col"><div class="small muted center">Проверяем</div></div>');
  openSheet('Проверка связи', body);

  const url = String(window.SPOKUM_SUPABASE_URL || '').replace(/\/$/, '');
  const key = window.SPOKUM_SUPABASE_KEY || '';
  const results = [];
  let serverDown = false;

  results.push({
    label: 'Настройки приложения',
    ok: !!(url && key),
    detail: url && key ? 'на месте' : 'не заданы'
  });

  results.push({
    label: 'Модуль связи',
    ok: !!window.supabase?.createClient,
    detail: window.supabase?.createClient ? 'загружен' : 'не загрузился'
  });

  results.push({
    label: 'Сеть устройства',
    ok: navigator.onLine,
    detail: navigator.onLine ? 'есть' : 'нет'
  });

  if (url && key) {
    results.push(await probe('Сервер', async () => {
      const response = await fetch(`${url}/auth/v1/health`, { headers: { apikey: key } });
      return response.ok ? 'отвечает' : `не отвечает, код ${response.status}`;
    }));
    // If server check failed, mark for the local-mode notice
    if (!results[results.length - 1].ok) serverDown = true;

    results.push(await probe('Данные', async () => {
      const response = await fetch(`${url}/rest/v1/profiles?select=id&limit=1`, {
        headers: { apikey: key, Authorization: `Bearer ${key}` }
      });
      if (!response.ok) throw new Error(`недоступны, код ${response.status}`);
      return 'читаются';
    }));

    results.push(await probe('Скорость', async () => {
      const times = [];
      for (let i = 0; i < 4; i++) {
        const started = performance.now();
        const response = await fetch(`${url}/rest/v1/profiles?select=id&limit=1`, {
          headers: { apikey: key, Authorization: `Bearer ${key}`, 'Cache-Control': 'no-cache' },
          cache: 'no-store'
        });
        if (!response.ok) throw new Error(`не измерить, код ${response.status}`);
        await response.text();
        if (i > 0) times.push(performance.now() - started);
      }
      const best = Math.round(Math.min(...times));
      const average = Math.round(times.reduce((sum, value) => sum + value, 0) / times.length);
      const verdict = average < 150
        ? 'близко, задержка почти не чувствуется'
        : average < 300
          ? 'терпимо, но заметно'
          : average < 600
            ? 'далеко, приложение будет подтормаживать'
            : 'очень далеко или связь плохая';
      return `${average} мс в среднем, лучший ответ ${best} мс. ${verdict}`;
    }));
  }

  body.innerHTML = `
    <div class="col" style="gap:8px">
      ${results.map((row) => `
        <div class="card" style="padding:12px">
          <div class="row" style="gap:10px">
            <span style="color:${row.ok ? 'var(--accent)' : '#c98b8b'}">${icon(row.ok ? 'check' : 'close', 16)}</span>
            <div class="grow"><div class="small strong">${esc(row.label)}</div>
            <div class="tiny muted" style="margin-top:2px;word-break:break-all">${esc(row.detail)}</div></div>
          </div>
        </div>`).join('')}
    </div>
    ${serverDown ? `
      <div class="card" style="padding:12px;border-color:rgba(232,160,48,.3);background:rgba(232,160,48,.05);margin-top:8px">
        <div class="row" style="gap:8px">
          <span style="color:#e8a030">${icon('warn', 18)}</span>
          <div class="grow">
            <div class="small strong" style="color:#e8a030">Сервер недоступен</div>
            <div class="tiny muted" style="margin-top:4px;line-height:1.5">
              Приложение переключилось в <b>локальный режим</b> — все данные хранятся в этом браузере.
              Вы можете регистрироваться, писать посты, играть и пользоваться всеми функциями.
              Когда сервер снова станет доступен, данные можно будет синхронизировать.
            </div>
          </div>
        </div>
      </div>` : ''}
    <p class="tiny muted" style="margin:4px 0 0">Если сервер не отвечает — приложение работает локально. Регистрируйтесь и пользуйтесь.</p>`;
}

export function renderAuth(root, done) {
  let mode = 'login';
  let avatar = null;
  const view = el(`
    <div class="auth-wrap">
      <div class="auth-card card appear">
        <div class="auth-logo">${logoMark(34)}</div>
        <div class="center">
          <div class="strong" style="font-size:24px;letter-spacing:-.02em">СпокУм</div>
          <div class="small muted" style="margin-top:6px">Соцсеть, где настроение важнее охватов</div>
        </div>
        <div class="tabs" style="margin:20px 0 16px">
          <button class="tab active" data-mode="login">Вход</button>
          <button class="tab" data-mode="register">Регистрация</button>
        </div>
        <div class="col" data-form></div>
        <div class="divider"></div>
        <button class="btn btn-ghost" data-guest style="width:100%">${icon('eye', 17)} Посмотреть без входа</button>
        <button class="btn btn-ghost btn-sm" data-check style="width:100%;margin-top:6px;color:var(--muted)">${icon('compass', 15)} Проверить связь</button>
      </div>
    </div>`);
  root.innerHTML = '';
  root.appendChild(view);

  const form = view.querySelector('[data-form]');

  const draw = () => {
    form.innerHTML = `
      ${mode === 'register' ? `<div class="row" style="justify-content:center;gap:12px">
        <div data-avatar></div>
        <button class="btn btn-sm" type="button" data-pick>${icon('image', 16)} Фото профиля</button>
      </div>` : ''}
      <input class="input" data-username placeholder="Юзернейм, например vanya8" autocomplete="username">
      ${mode === 'register' ? '<input class="input" data-name placeholder="Как тебя называть" autocomplete="nickname">' : ''}
      <input class="input" type="password" data-password placeholder="Пароль" autocomplete="${mode === 'login' ? 'current-password' : 'new-password'}">
      <button class="btn btn-primary" data-submit>${mode === 'login' ? 'Войти' : 'Создать аккаунт'}</button>
      ${mode === 'login' ? '<button type="button" class="btn btn-ghost btn-sm" data-forgot>Забыли пароль?</button>' : ''}
      <p class="tiny muted center" style="margin:0;line-height:1.5">${mode === 'login' ? 'Нет аккаунта? Переключись на регистрацию' : 'Минимум 8 символов в пароле. Данные остаются приватными'}</p>
      ${mode === 'register' ? '<p class="tiny muted center" style="margin:0;line-height:1.6">Создавая аккаунт, вы принимаете <a href="/offer.html" target="_blank" class="link-btn">пользовательское соглашение</a>, <a href="/privacy.html" target="_blank" class="link-btn">политику конфиденциальности</a> и <a href="/consent.html" target="_blank" class="link-btn">согласие на обработку данных</a></p>' : ''}`;

    form.querySelector('[data-rules]')?.addEventListener('click', async () => {
      const { openRules } = await import('./rules.js?v=20251018');
      openRules();
    });

    const preview = form.querySelector('[data-avatar]');
    const drawAvatar = () => {
      if (!preview) return;
      const name = form.querySelector('[data-name]')?.value || form.querySelector('[data-username]')?.value || '';
      preview.innerHTML = avatar
        ? `<div class="avatar avatar-54" style="--h:220"><img src="${esc(avatar)}" alt=""></div>`
        : `<div class="avatar avatar-54" style="--h:220">${esc(initials(name) === '?' ? '' : initials(name))}</div>`;
    };
    drawAvatar();

    form.querySelector('[data-pick]')?.addEventListener('click', async () => {
      const image = await pickImage(360);
      if (image) {
        avatar = image;
        drawAvatar();
      }
    });
    form.querySelector('[data-name]')?.addEventListener('input', drawAvatar);
    form.querySelector('[data-username]')?.addEventListener('input', drawAvatar);

    const submit = async () => {
      const username = form.querySelector('[data-username]').value.trim();
      const password = form.querySelector('[data-password]').value;
      const displayName = form.querySelector('[data-name]')?.value.trim();
      if (!username || !password) return toast('Заполните поля', 'err');
      const button = form.querySelector('[data-submit]');
      const label = button.textContent;
      button.disabled = true;
      button.textContent = mode === 'login' ? 'Входим' : 'Создаём аккаунт';
      try {
        const result = mode === 'login'
          ? await api.login({ username, password })
          : await api.register({ username, displayName: displayName || username, password, avatar });
        setUser(result.user);
        if (mode === 'register' && avatar) {
          try {
            const { user } = await api.updateMe({ avatar });
            setUser(user);
          } catch {}
        }
        try {
          const { deviceInfo, rememberBlock } = await import('../device.js?v=20251018');
          const info = await deviceInfo();
          const { state: ban } = await api.touchDevice(info, mode === 'register');
          rememberBlock(ban);
          if (ban?.blocked) {
            await api.logout?.();
            setUser(null);
            toast(ban.forever || !ban.until ? 'Это устройство заблокировано навсегда' : 'Это устройство заблокировано', 'err');
            location.reload();
            return;
          }
        } catch {}
        try {
          const { rememberCurrent } = await import('../accounts.js?v=20251018');
          await rememberCurrent();
        } catch {}
        done();
      } catch (error) {
        toast(error.message, 'err');
      } finally {
        button.disabled = false;
        button.textContent = label;
      }
    };

    form.querySelector('[data-forgot]')?.addEventListener('click', () => openRecovery(form.querySelector('[data-username]').value.trim(), done));
    form.querySelector('[data-submit]').onclick = submit;
    form.querySelectorAll('input').forEach((input) => {
      input.addEventListener('keydown', (event) => {
        if (event.key === 'Enter') submit();
      });
    });
  };

  view.querySelectorAll('[data-mode]').forEach((button) => {
    button.onclick = () => {
      mode = button.dataset.mode;
      avatar = null;
      view.querySelectorAll('[data-mode]').forEach((b) => b.classList.toggle('active', b === button));
      draw();
    };
  });
  view.querySelector('[data-guest]').onclick = () => done();
  view.querySelector('[data-check]').onclick = () => runDiagnostics();
  draw();
}
