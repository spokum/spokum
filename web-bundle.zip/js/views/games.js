import { api, state, isPremium, isBeta } from '../store.js';
import { GAMES } from '../games/index.js';
import { el, esc } from '../util.js';
import { icon } from '../icons.js';
import { avatar, toast, emptyState } from '../ui.js';

const bestKey = (id) => `spokum.best.${id}`;

export async function render(root) {
  root.innerHTML = `
    <div class="topbar">
      <div><h1>Игры</h1><p class="sub">Разгрузить голову на пять минут</p></div>
    </div>
    <div class="game-grid" data-grid></div>
    <div class="row between" style="margin:22px 2px 10px">
      <div class="strong small">Таблица лидеров</div>
      <div class="row" style="gap:8px">
        <button class="btn btn-sm" data-game-achv title="Игровые достижения">${icon('trophy', 14)} Достижения</button>
        <select class="select" data-game style="width:auto;padding:6px 10px;font-size:12px">
          ${GAMES.map((g) => `<option value="${g.id}">${esc(g.title)}</option>`).join('')}
        </select>
      </div>
    </div>
    <div class="card" data-board></div>`;

  const grid = root.querySelector('[data-grid]');
  const paid = isPremium(state.user);
  const beta = isBeta(state.user);
  const shown = [...GAMES].sort((a, b) => Number(!!b.premium) - Number(!!a.premium));
  shown.forEach((game) => {
    const best = Number(localStorage.getItem(bestKey(game.id)) || 0);
    // Premium games are gated to beta testers (@silver, @ulquiorra_cifer,
    // admin-flagged isBeta) OR active premium subscribers.
    const locked = !!game.premium && !paid && !beta;
    const card = el(`
      <button class="game-card appear${locked ? ' locked' : ''}">
        <div class="art" style="background:linear-gradient(150deg,${game.tint[0]},${game.tint[1]})"></div>
        <div class="art" style="background:radial-gradient(60% 60% at 80% 15%, rgba(255,255,255,.16), transparent 70%)"></div>
        <div class="row" style="position:relative;margin-bottom:auto;color:#eef2fb;opacity:.9">
          ${icon(locked ? 'lock' : 'play', 22)}
          <div class="spacer"></div>
          ${game.premium ? `<span class="game-pro">${icon('crown', 11)}<span>${beta && !paid ? 'Бета' : 'Премиум'}</span></span>` : ''}
        </div>
        <div class="label" style="color:#eef2fb">${esc(game.title)}</div>
        <div class="desc">${esc(game.desc)}</div>
        ${best ? `<div class="desc" style="color:var(--accent)">Рекорд ${best}</div>` : ''}
      </button>`);
    card.onclick = async () => {
      if (!locked) return launch(game, () => render(root));
      toast(beta && !paid
        ? 'Игра открыта бета-тестерам — скоро будет у всех'
        : 'Игра открыта по подписке СпокУм Премиум или для бета-тестеров', 'err');
      const { openBilling } = await import('./settings.js?v=20251028');
      openBilling?.();
    };
    grid.appendChild(card);
  });

  root.querySelector('[data-game-achv]')?.addEventListener('click', async () => {
    const { openGameAchievements } = await import('./game-achievements.js?v=20251028');
    openGameAchievements();
  });

  const select = root.querySelector('[data-game]');
  const board = root.querySelector('[data-board]');
  const drawBoard = async () => {
    try {
      const { leaderboard } = await api.leaderboard(select.value);
      board.innerHTML = leaderboard.length
        ? leaderboard
            .map(
              (row, i) => `<div class="list-item" style="padding:8px 6px"><span class="strong muted" style="width:22px">${i + 1}</span>
                ${avatar(row, 40)}<div class="grow"><div class="strong small truncate">${esc(row.displayName || row.display_name || '')}</div>
                <div class="tiny muted">@${esc(row.username)}</div></div><span class="strong">${row.score}</span></div>`
            )
            .join('')
        : emptyState('trophy', 'Рекордов ещё нет', 'Сыграй первым и займи вершину');
    } catch (error) {
      board.innerHTML = emptyState('warn', 'Не загрузилось', error.message);
    }
  };
  select.onchange = drawBoard;
  await drawBoard();
}

function launch(game, done) {
  try {
    const current = Number(localStorage.getItem('spokum.gamesPlayed')) || 0;
    localStorage.setItem('spokum.gamesPlayed', String(current + 1));
  } catch {}
  const stage = el(`
    <div class="game-stage">
      <header>
        <button class="btn btn-icon btn-ghost" data-back>${icon('back', 20)}</button>
        <div class="grow"><div class="strong small">${esc(game.title)}</div><div class="tiny" style="opacity:.6">${esc(game.desc)}</div></div>
        <div class="pill" data-best></div>
      </header>
      <div class="game-hint" data-hint>${hintFor(game.id)}</div>
      <canvas></canvas>
    </div>`);
  document.body.appendChild(stage);
  const canvas = stage.querySelector('canvas');
  const hint = stage.querySelector('[data-hint]');
  // Auto-hide the how-to-play hint after 6s or on first interaction.
  let hintHidden = false;
  const hideHint = () => {
    if (hintHidden) return;
    hintHidden = true;
    hint.style.transition = 'opacity .25s ease';
    hint.style.opacity = '0';
    setTimeout(() => { hint.remove(); }, 300);
  };
  setTimeout(hideHint, 6000);
  canvas.addEventListener('pointerdown', hideHint, { once: true });
  canvas.addEventListener('keydown', hideHint, { once: true });
  const bestBox = stage.querySelector('[data-best]');
  let best = Number(localStorage.getItem(bestKey(game.id)) || 0);
  bestBox.textContent = `Рекорд ${best}`;

  let paidFor = 0;
  let busy = false;
  let recorded = false;

  const report = async (score) => {
    if (score > best) {
      best = score;
      localStorage.setItem(bestKey(game.id), String(score));
      bestBox.textContent = `Рекорд ${best}`;
      toast(`Новый рекорд ${score}`);
    }
    // Track game achievements (local-only stats). Fire-and-forget.
    // Guard against double-counting when the game calls report on game-over
    // AND the back button calls it again on exit.
    if (!recorded) {
      recorded = true;
      try {
        const { recordGamePlay } = await import('./game-achievements.js?v=20251028');
        recordGamePlay(game.id, score);
      } catch {}
    }
    if (!state.user || busy) return;
    busy = true;
    try {
      await api.saveScore(game.id, score).catch(() => {});
      const earned = Math.min(50, Math.floor(score / 200));
      if (api.grantCoins && earned > 0 && score > paidFor) {
        paidFor = score;
        const purse = await api.grantCoins(earned, `Игра: ${game.title}`);
        if (purse?.added > 0) {
          toast(`+${purse.added} монет`);
          const { setUser } = await import('../store.js?v=20251028');
          const { user } = await api.me();
          if (user) setUser(user);
        }
      } else if (score > paidFor) {
        paidFor = score;
      }
    } catch {}
    busy = false;
  };

  let handle = null;
  requestAnimationFrame(() => {
    handle = game.mount(canvas, report);
  });

  stage.querySelector('[data-back]').onclick = async () => {
    const current = handle ? handle.score() : 0;
    handle?.stop();
    stage.remove();
    if (current > 0) await report(current);
    done?.();
  };
}

/* Per-game "how to play" hints shown above the canvas for the first few
   seconds of a session. Covers the six premium games and a generic
   fallback for the rest. */
const HINTS = {
  sky: 'Веди палец по экрану, чтобы поворачивать. Лети сквозь кольца, уворачивайся от скал. Чем дольше летишь — тем быстрее.',
  roll: 'Веди палец, чтобы наклонять поле. Докати шар до светящегося кольца наверху. Не падай в дыры — у тебя 5 жизней.',
  space: 'Води влево-вправо, чтобы двигать корабль. Тап — выстрел. Сбивай астероиды, не дай им коснуться корабля.',
  racer: 'Води влево-вправо, чтобы уворачиваться от машин. Чем дольше едешь — тем быстрее.',
  doom: 'Веди палец, чтобы осмотреться. Верх экрана — вперёд, низ — стреляй. Найди и убей всех монстров на уровне.',
  survivor: 'Веди палец, чтобы двигаться. Тап — выстрел в сторону касания. Отстреливайся от волн врагов, не дай себя окружить.'
};

function hintFor(id) {
  return esc(HINTS[id] || 'Управление зависит от игры. Тап — действие, свайп — движение.');
}
