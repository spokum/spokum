import { api, state, isOffline, isPremium } from '../store.js';
import { el, esc, timeAgo, clockTime, durationText, debounce, plural } from '../util.js';
import { icon } from '../icons.js';
import { avatar, badges, toast, openSheet, emptyState, pickImage, promptSheet, confirmSheet } from '../ui.js';
import { openProfile } from './profile.js';

const EMOJI = [];

let listRoot = null;

export async function render(root) {
  listRoot = root;
  root.innerHTML = `
    <div class="topbar">
      <div><h1>Чаты</h1><p class="sub">Разговоры без шума</p></div>
      <div class="spacer"></div>
      <button class="btn btn-icon" data-new title="Создать">${icon('plus', 18)}</button>
    </div>
    <div class="row" style="margin-bottom:12px">
      <div class="grow" style="position:relative">
        <input class="input" data-search placeholder="Поиск людей по @юзернейму или словам" style="padding-left:42px">
        <div style="position:absolute;left:14px;top:50%;transform:translateY(-50%);color:var(--muted)">${icon('search', 18)}</div>
      </div>
    </div>
    <button class="card list-item" data-random-chat style="margin-bottom:12px;padding:14px">${icon('users', 20)}<div class="grow"><div class="strong small">Случайный собеседник</div><div class="tiny muted">Анонимный чат 1-на-1</div></div>${icon('forward', 16)}</button>
    <div data-results></div>
    <div data-channels style="margin-bottom:12px"></div>
    <div class="col chat-tg chat-list" data-list style="gap:2px"></div>`;

  root.querySelector('[data-new]').onclick = openCreate;
  root.querySelector('[data-random-chat]').onclick = async () => {
    const { openRandomChat } = await import('./random-chat.js?v=20251028');
    openRandomChat();
  };
  const search = root.querySelector('[data-search]');
  const results = root.querySelector('[data-results]');
  search.addEventListener('input', debounce(async () => {
    const q = search.value.trim();
    if (!q) {
      results.innerHTML = '';
      return;
    }
    const { users } = await api.searchUsers(q);
    const others = users.filter((u) => u.id !== state.user?.id);
    results.innerHTML = others.length
      ? `<div class="card" style="padding:8px;margin-bottom:12px">${others
          .map(
            (u) => `<button class="list-item" data-user="${u.id}" data-name="${esc(u.username)}">${avatar(u, 40)}
              <div class="grow"><div class="row" style="gap:6px"><span class="strong small">${esc(u.displayName)}</span>${badges(u)}</div>
              <div class="tiny muted truncate">@${esc(u.username)}${u.bio ? ` · ${esc(u.bio)}` : ''}</div></div>${icon('send', 16)}</button>`
          )
          .join('')}</div>`
      : `<div class="card small muted center" style="margin-bottom:12px">Никого не нашли</div>`;
    results.querySelectorAll('[data-user]').forEach((button) => {
      button.onclick = async () => {
        try {
          const { chat } = await api.createChat({ kind: 'dm', members: [button.dataset.user] });
          search.value = '';
          results.innerHTML = '';
          await load(root);
          openChat(chat.id);
        } catch (error) {
          toast(error.message, 'err');
        }
      };
    });
  }, 260));

  await load(root);
  loadRecommendedChannels(root);
}

async function loadRecommendedChannels(root) {
  const host = root.querySelector('[data-channels]');
  if (!host) return;
  if (!api.recommendedChannels) { host.innerHTML = ''; return; }
  let channels = [];
  try {
    ({ channels } = await api.recommendedChannels());
  } catch {
    host.innerHTML = '';
    return;
  }
  if (!channels.length) { host.innerHTML = ''; return; }
  host.innerHTML = `
    <div class="row between" style="margin:0 2px 8px">
      <div class="strong small">${icon('channel', 16)} Каналы</div>
      <button class="btn btn-sm btn-ghost" data-all-channels>${icon('search', 14)} Все</button>
    </div>
    <div class="col" data-channel-list style="gap:6px"></div>`;
  const list = host.querySelector('[data-channel-list]');
  channels.forEach((c) => {
    const row = el(`<div class="channel-card" data-channel="${c.id}">
      <div class="channel-mark" style="background:hsl(${Number(c.hue) || 200} 38% 22%)">${esc((c.title || '?')[0].toUpperCase())}</div>
      <div class="grow" style="min-width:0">
        <div class="small strong truncate">${esc(c.title)}</div>
        <div class="tiny muted">${plural(c.members || 0, 'подписчик', 'подписчика', 'подписчиков')}${c.owner ? ` · @${esc(c.owner.username)}` : ''}</div>
      </div>
      ${c.isOwner
        ? '<span class="pill good tiny">ваш</span>'
        : c.joined
          ? `<button class="btn btn-sm" data-unfollow="${c.id}">Отписаться</button>`
          : `<button class="btn btn-sm btn-primary" data-follow="${c.id}">Подписаться</button>`}
    </div>`);
    row.onclick = async (event) => {
      if (event.target.closest('[data-follow]') || event.target.closest('[data-unfollow]')) return;
      try { openChat(Number(c.id)); } catch (e) { toast(e.message, 'err'); }
    };
    const follow = row.querySelector('[data-follow]');
    if (follow) follow.onclick = async (event) => {
      event.stopPropagation();
      try { await api.followChannel(Number(follow.dataset.follow)); toast('Вы подписаны'); loadRecommendedChannels(root); }
      catch (e) { toast(e.message, 'err'); }
    };
    const unfollow = row.querySelector('[data-unfollow]');
    if (unfollow) unfollow.onclick = async (event) => {
      event.stopPropagation();
      try { await api.unfollowChannel(Number(unfollow.dataset.unfollow)); toast('Вы отписались'); loadRecommendedChannels(root); }
      catch (e) { toast(e.message, 'err'); }
    };
    list.appendChild(row);
  });
  host.querySelector('[data-all-channels]').onclick = () => {
    import('./search.js?v=20251028').then(({ openSearch }) => openSearch());
  };
}

async function load(root) {
  const list = root.querySelector('[data-list]');
  if (!state.user) {
    list.innerHTML = emptyState('chats', 'Нужен вход', 'Войдите, чтобы переписываться');
    return;
  }
  if (isOffline()) {
    list.innerHTML = emptyState('warn', 'Нет интернета', 'Переписка станет доступна, когда связь вернётся');
    return;
  }
  let chats;
  try {
    ({ chats } = await api.chats());
  } catch (error) {
    list.innerHTML = emptyState('warn', 'Не загрузилось', error.message);
    return;
  }
  if (!chats.length) {
    list.innerHTML = emptyState('chats', 'Пока пусто', 'Найдите человека через поиск выше');
    return;
  }
  list.innerHTML = '';
  chats.forEach((chat) => {
    const last = chat.lastMessage;
    const preview = last
      ? last.kind === 'sticker'
        ? (last.body && !last.media ? `Стикер ${last.body}` : 'Стикер')
        : last.kind === 'image'
        ? 'Фотография'
        : last.kind === 'voice'
          ? `Голосовое ${durationText(last.duration)}`
          : last.kind === 'call'
            ? last.body
            : last.body
      : 'Ещё нет сообщений';
    const mark = chat.kind === 'group' ? icon('group', 13) : chat.kind === 'channel' ? icon('channel', 13) : '';
    const node = el(`
      <button class="card list-item appear chat-tg-row" style="padding:14px">
        ${chat.peer ? avatar(chat.peer, 52) : `<div class="avatar avatar-52" style="--h:${chat.hue}">${esc((chat.title || '?')[0].toUpperCase())}</div>`}
        <div class="grow" style="min-width:0">
          <div class="row" style="gap:6px">
            ${mark ? `<span class="muted">${mark}</span>` : ''}
            <span class="strong small truncate">${esc(chat.title)}</span>
            ${chat.peer ? badges(chat.peer) : ''}
            <div class="grow"></div>
            <span class="tiny muted chat-tg-time">${last ? timeAgo(last.createdAt) : ''}</span>
          </div>
          <div class="row" style="gap:6px;margin-top:2px">
            <span class="tiny muted truncate grow chat-tg-preview">${esc(preview)}</span>
            ${chat.unread ? `<span class="chat-tg-unread">${chat.unread}</span>` : ''}
          </div>
        </div>
      </button>`);
    node.onclick = () => openChat(chat.id);
    list.appendChild(node);
  });
}

function openCreate() {
  const body = el(`
    <div class="col" style="gap:6px">
      <button class="list-item" data-group>${icon('group', 20)}<div class="grow"><div class="strong small">Новая группа</div><div class="tiny muted">Общий чат с друзьями</div></div></button>
      <button class="list-item" data-channel>${icon('channel', 20)}<div class="grow"><div class="strong small">Новый канал</div><div class="tiny muted">Вы пишете, остальные читают</div></div></button>
    </div>`);
  const sheet = openSheet('Создать', body);
  const make = async (kind) => {
    sheet.close();
    const title = await promptSheet({ title: kind === 'group' ? 'Название группы' : 'Название канала', placeholder: 'Например: Вечерний круг' });
    if (!title) return;
    try {
      const { chat } = await api.createChat({ kind, title, members: [] });
      await load(listRoot);
      openChat(chat.id);
    } catch (error) {
      toast(error.message, 'err');
    }
  };
  body.querySelector('[data-group]').onclick = () => make('group');
  body.querySelector('[data-channel]').onclick = () => make('channel');
}

export async function openChat(chatId) {
  const { chats } = await api.chats();
  const chat = chats.find((c) => c.id === chatId);
  if (!chat) return toast('Чат не найден', 'err');

  const view = el(`
    <div class="chat-view chat-tg">
      <div class="chat-head">
        <button class="btn btn-icon btn-ghost" data-back>${icon('back', 20)}</button>
        <button style="display:contents" data-peer>
          ${chat.peer ? avatar(chat.peer, 40) : `<div class="avatar avatar-40" style="--h:${chat.hue}">${esc((chat.title || '?')[0].toUpperCase())}</div>`}
        </button>
        <div class="grow" style="min-width:0">
          <div class="row" style="gap:6px"><span class="strong small truncate">${esc(chat.title)}</span>${chat.peer ? badges(chat.peer) : ''}</div>
          <div class="tiny muted truncate chat-tg-status">${chat.kind === 'dm' ? (chat.peer?.lastSeen ? `был(а) ${timeAgo(chat.peer.lastSeen)}` : 'online') : `${chat.members.length} участников`}</div>
        </div>
        ${chat.kind === 'dm' ? `<button class="btn btn-icon btn-ghost" data-video-call>${icon('video', 19)}</button>
        <button class="btn btn-icon btn-ghost" data-call>${icon('phone', 19)}</button>` : ''}
        <button class="btn btn-icon btn-ghost" data-menu>${icon('more', 19)}</button>
      </div>
      <div class="chat-body" data-body></div>
      <div class="chat-foot">
        <button class="btn btn-icon btn-ghost" data-emoji>${icon('smile', 19)}</button>
        <button class="btn btn-icon btn-ghost" data-emoji-sticker title="Стикеры">${icon('spark', 19)}</button>
        <button class="btn btn-icon btn-ghost" data-stickers title="Свои стикеры">${icon('star', 19)}</button>
        <button class="btn btn-icon btn-ghost" data-image>${icon('image', 19)}</button>
        <textarea class="input grow chat-tg-input" data-input rows="1" placeholder="Сообщение" style="min-height:44px;max-height:120px;resize:none;padding:11px 16px"></textarea>
        <button class="btn btn-icon btn-ghost" data-voice>${icon('mic', 19)}</button>
        <button class="btn btn-primary btn-icon chat-tg-send" data-send>${icon('send', 18)}</button>
      </div>
    </div>`);
  document.body.appendChild(view);

  const body = view.querySelector('[data-body]');
  const input = view.querySelector('[data-input]');
  const readOnly = chat.kind === 'channel' && chat.role !== 'owner' && !state.user?.isAdmin;
  if (readOnly) {
    view.querySelector('.chat-foot').innerHTML = '<div class="small muted center grow" style="padding:10px">В канале пишет только владелец</div>';
  }

  view.querySelector('[data-back]').onclick = () => {
    view.remove();
    load(listRoot);
  };
  view.querySelector('[data-peer]').onclick = () => {
    if (chat.peer) openProfile(chat.peer.username);
    else openMembers(chat);
  };
  view.querySelector('[data-menu]').onclick = () => openChatMenu(chat, view);
  view.querySelector('[data-call]')?.addEventListener('click', async () => {
    const { startCall } = await import('../call.js?v=20251028');
    startCall(chat);
  });
  view.querySelector('[data-video-call]')?.addEventListener('click', async () => {
    const { startCall } = await import('../call.js?v=20251028');
    startCall(chat, { video: true });
  });

  const draw = async () => {
    const [{ messages }, reactions] = await Promise.all([
      api.messages(chatId),
      api.chatReactions
        ? api.chatReactions(chatId).then((answer) => answer.reactions || {}).catch(() => ({}))
        : Promise.resolve({})
    ]);
    const atBottom = body.scrollHeight - body.scrollTop - body.clientHeight < 120;
    body.innerHTML = '';
    if (!messages.length) {
      body.innerHTML = `<div style="margin:auto">${emptyState('wave', 'Начните разговор', 'Здесь спокойно и без спешки')}</div>`;
    }
    let lastAuthor = null;
    for (const message of messages) {
      const node = bubble(message, chat, lastAuthor);
      wireReact(node, message, reactions[message.id] || [], draw);
      body.appendChild(node);
      lastAuthor = message.author?.id;
    }
    if (atBottom || true) body.scrollTop = body.scrollHeight;
    api.markRead(chatId);
  };
  await draw();

  const refresh = () => draw();
  window.addEventListener('spokum:message', refresh);
  const observer = new MutationObserver(() => {
    if (!document.body.contains(view)) {
      window.removeEventListener('spokum:message', refresh);
      observer.disconnect();
    }
  });
  observer.observe(document.body, { childList: true });

  let replyTarget = null;
  const replyBar = el('<div class="row between" data-reply-bar style="display:none;padding:6px 14px;background:var(--bg-2);align-items:center;gap:8px"><div class="tiny muted" data-reply-text style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"></div><button class="btn btn-sm" data-reply-cancel style="padding:2px 8px">x</button></div>');
  view.querySelector('.chat-foot').insertAdjacentElement('beforebegin', replyBar);
  replyBar.querySelector('[data-reply-cancel]').onclick = () => { replyTarget = null; replyBar.style.display = 'none'; };
  window.addEventListener('spokum:replyMessage', (e) => {
    replyTarget = e.detail;
    replyBar.style.display = 'flex';
    const txt = replyTarget.body || replyTarget.kind || 'сообщение';
    replyBar.querySelector('[data-reply-text]').textContent = 'Ответ: ' + (txt.length > 40 ? txt.slice(0, 40) + '...' : txt);
    input.focus();
  });

  const send = async (payload) => {
    if (isOffline()) return toast('Нет интернета, сообщение не уйдёт', 'err');
    try {
      if (replyTarget) { payload.replyToId = replyTarget.id; replyTarget = null; replyBar.style.display = 'none'; }
      await api.sendMessage(chatId, payload);
      input.value = '';
      input.style.height = '';
      await draw();
    } catch (error) {
      toast(error.message, 'err');
    }
  };

  view.querySelector('[data-send]')?.addEventListener('click', () => {
    const text = input.value.trim();
    if (text) send({ kind: 'text', body: text });
  });
  input?.addEventListener('keydown', (event) => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      const text = input.value.trim();
      if (text) send({ kind: 'text', body: text });
    }
  });
  input?.addEventListener('input', () => {
    input.style.height = 'auto';
    input.style.height = `${Math.min(120, input.scrollHeight)}px`;
  });

  view.querySelector('[data-image]')?.addEventListener('click', async () => {
    const image = await pickImage(1200);
    if (image) send({ kind: 'image', media: image });
  });

  view.querySelector('[data-emoji]')?.addEventListener('click', () => {
    const grid = el(`<div class="emoji-grid">${EMOJI.map((e) => `<button data-e="${e}">${e}</button>`).join('')}</div>`);
    const sheet = openSheet('Эмодзи', grid);
    grid.querySelectorAll('[data-e]').forEach((button) => {
      button.onclick = () => {
        input.value += button.dataset.e;
        sheet.close();
        input.focus();
      };
    });
  });

  view.querySelector('[data-stickers]')?.addEventListener('click', () => openStickers(send));

  view.querySelector('[data-emoji-sticker]')?.addEventListener('click', async () => {
    const { openStickerPicker } = await import('./stickers.js?v=20251028');
    openStickerPicker((emoji) => send({ kind: 'sticker', body: emoji }));
  });

  view.querySelector('[data-voice]')?.addEventListener('click', () => recordVoice(send));
}

const REACTS = [
  { icon: 'same', label: 'Согласен' },
  { icon: 'heart', label: 'Любовь' },
  { icon: 'spark', label: 'Радость' },
  { icon: 'wave', label: 'Грусть' },
  { icon: 'flame', label: 'Огонь' }
];

function wireReact(node, message, rows, done) {
  if (!api.reactMessage || message.kind === 'system' || message.kind === 'call') return;
  if (rows.length) {
    const seen = {};
    rows.forEach((row) => {
      seen[row.glyph] = (seen[row.glyph] || 0) + 1;
    });
    const strip = el(`<div class="react-strip">${Object.entries(seen)
      .map(([glyph, count]) => {
        const iconName = ['same','heart','spark','wave','flame'].includes(glyph) ? glyph : 'spark';
        return `<span class="react-chip" data-glyph="${esc(glyph)}">${icon(iconName, 16)}${count > 1 ? `<i>${count}</i>` : ''}</span>`;
      })
      .join('')}</div>`);
    strip.querySelectorAll('.react-chip').forEach((chip) => {
      const glyph = chip.dataset.glyph;
      chip.addEventListener('click', async (event) => {
        event.stopPropagation();
        const mine = rows.find((row) => String(row.user) === String(state.user?.id));
        if (mine?.glyph !== glyph) return; // only allow removing your own
        try {
          await api.reactMessage(message.id, '');
          done?.();
        } catch (e) { toast(e.message, 'err'); }
      });
    });
    node.appendChild(strip);
  }

  let timer = null;
  const open = () => {
    const mine = rows.find((row) => String(row.user) === String(state.user?.id));
    const menu = el(`<div class="react-row">
      ${REACTS.map((r) => `<button class="react-pick ${mine?.glyph === r.icon ? 'on' : ''}" data-react="${r.icon}" title="${r.label}">${icon(r.icon, 20)}</button>`).join('')}
    </div>`);
    const sheet = openSheet('', menu);
    menu.querySelectorAll('[data-react]').forEach((button) => {
      button.onclick = async () => {
        sheet.close();
        try {
          const next = mine?.glyph === button.dataset.react ? '' : button.dataset.react;
          await api.reactMessage(message.id, next);
          done?.();
        } catch (error) {
          toast(error.message, 'err');
        }
      };
    });
  };

  node.addEventListener('pointerdown', () => {
    timer = setTimeout(open, 480);
  });
  ['pointerup', 'pointerleave', 'pointercancel'].forEach((type) => {
    node.addEventListener(type, () => clearTimeout(timer));
  });
  node.addEventListener('dblclick', (event) => {
    event.preventDefault();
    open();
  });
}

const SAFE_HOSTS = ['spokum.github.io', 'github.com', 't.me', 'telegram.org', 'youtube.com', 'youtu.be', 'vk.com', 'ok.ru', 'wikipedia.org', 'yandex.ru', 'google.com', 'rutube.ru', 'dzen.ru'];

function linkWarning(text) {
  const found = String(text || '').match(/https?:\/\/[^\s]+|(?:^|\s)[a-z0-9-]+\.(?:ru|com|net|org|io|xyz|top|info|site|online|link)(?:\/[^\s]*)?/gi);
  if (!found) return '';
  const risky = found
    .map((raw) => raw.trim().replace(/^https?:\/\//i, '').split('/')[0].toLowerCase())
    .filter((host) => host && !SAFE_HOSTS.some((safe) => host === safe || host.endsWith('.' + safe)));
  if (!risky.length) return '';
  const odd = risky.find((host) => /xn--|[а-яё]/i.test(host) || host.split('.').length > 3 || host.length > 30);
  return `<div class="link-warn">${icon('warn', 13)}<span>${odd
    ? 'Ссылка выглядит подозрительно, домен маскируется под чужой. Не вводите там пароли'
    : 'Ссылка ведёт на незнакомый сайт. Не вводите там пароль от СпокУма'}</span></div>`;
}

function bubble(message, chat, lastAuthor) {
  const mine = message.author?.id === state.user?.id;
  if (message.kind === 'call') {
    return el(`<div class="bubble system">${icon('phone', 12)} ${esc(message.body)}</div>`);
  }
  if (message.kind === 'gift') {
    return el(`<div class="bubble gift-note">${icon('gift', 15)}<span>${esc(message.body)}</span></div>`);
  }
  const showAuthor = chat.kind !== 'dm' && !mine && message.author?.id !== lastAuthor;
  let inner = '';
  if (message.kind === 'sticker') {
    inner = message.media
      ? `<img class="sticker" src="${esc(message.media)}" alt="стикер" loading="lazy">`
      : (() => { const s = String(message.body || ''); const iconNames = ['leaf','cup','moon','flame','heart','same','spark','rose','star','hold']; return iconNames.includes(s) ? `<span class="sticker-icon">${icon(s, 48)}</span>` : `<span class="sticker-emoji">${esc(s)}</span>`; })();
  } else if (message.kind === 'image') inner = `<img src="${esc(message.media)}" alt="" loading="lazy">${message.body ? `<div style="margin-top:6px">${esc(message.body)}</div>` : ''}`;
  else if (message.kind === 'voice') {
    const bars = Array.from({ length: 22 }, (_, i) => `<i style="height:${20 + Math.round(Math.sin(i * 1.7 + message.id) * 55 + 55) * 0.6}%"></i>`).join('');
    inner = `<div class="voice"><button class="btn btn-icon btn-ghost" data-play style="width:32px;height:32px">${icon('play', 15)}</button><div class="voice-bars">${bars}</div><span class="tiny">${durationText(message.duration)}</span></div>`;
  } else if (message.kind === 'video') {
    inner = `<div class="chat-reel" data-reel><video src="${esc(message.media || '')}" playsinline muted loop preload="metadata"></video><span class="chat-reel-play">${icon('play', 22)}</span></div>${message.body ? `<div style="margin-top:6px">${esc(message.body)}</div>` : ''}`;
  } else if (message.kind === 'post') {
    inner = `<div class="chat-reel" data-reel>${message.media ? `<img src="${esc(message.media)}" alt="" loading="lazy">` : `<span class="chat-reel-play">${icon('feed', 22)}</span>`}</div>${message.body ? `<div style="margin-top:6px">${esc(message.body)}</div>` : ''}`;
  } else inner = esc(message.body) + linkWarning(message.body);

  const seen = mine && message.createdAt <= (chat.peerReadAt || 0);
  const ticks = mine ? `<span class="ticks ${seen ? 'seen' : ''}">${icon(seen ? 'check_double' : 'check', 13, 2.6)}</span>` : '';
  
  const canDelete = mine && message.kind !== 'call' && message.kind !== 'gift' && message.kind !== 'system' && !message.removed;
  const delBtn = canDelete ? `<button class="bubble-del" data-del-msg title="Удалить">${icon('trash', 12)}</button>` : '';
  const replyBtn = !message.removed && message.kind !== 'call' && message.kind !== 'gift' && message.kind !== 'system' ? `<button class="bubble-del" data-reply-msg title="Ответить">${icon('reply', 12)}</button>` : '';
  const replyBadge = message.replyToId ? `<div class="tiny muted" style="margin-bottom:4px;opacity:.6;border-left:2px solid var(--accent);padding-left:6px">ответ</div>` : '';
  const removedBadge = message.removed ? `<div class="tiny muted" style="font-style:italic">сообщение удалено</div>` : '';
  const node = el(`<div class="bubble ${mine ? 'mine' : ''} ${message.kind === 'sticker' ? 'bubble-sticker' : ''}">${showAuthor ? `<div class="bubble-author">${esc(message.author?.displayName || '')}</div>` : ''}${replyBadge}${removedBadge || inner}<div class="bubble-meta">${clockTime(message.createdAt)}${ticks}${replyBtn}${delBtn}</div></div>`);

  const reel = node.querySelector('[data-reel]');
  if (reel) {
    const clip = reel.querySelector('video');
    reel.onclick = () => {
      if (!clip) {
        window.__spokum?.openTab?.('videos');
        return;
      }
      if (clip.paused) {
        clip.muted = false;
        clip.play().catch(() => {
          clip.muted = true;
          clip.play().catch(() => {});
        });
        reel.classList.add('playing');
      } else {
        clip.pause();
        reel.classList.remove('playing');
      }
    };
  }

  const play = node.querySelector('[data-play]');
  if (play) {
    const audio = new Audio(message.media);
    play.onclick = () => {
      if (audio.paused) {
        audio.play();
        play.innerHTML = icon('pause', 15);
      } else {
        audio.pause();
        play.innerHTML = icon('play', 15);
      }
    };
    audio.onended = () => {
      play.innerHTML = icon('play', 15);
    };
  }
  
  const delMsg = node.querySelector('[data-del-msg]');
  if (delMsg) {
    delMsg.onclick = async (event) => {
      event.stopPropagation();
      const ok = await confirmSheet({ title: 'Удалить сообщение?', text: 'Оно пропадёт у всех собеседников.', confirm: 'Удалить', danger: true });
      if (!ok) return;
      try {
        await api.deleteMyMessage(message.id);
        toast('Удалено');
        const draw2 = node.closest('[data-host')?.__draw;
        if (typeof draw2 === 'function') draw2();
        else window.location.reload();
      } catch (error) {
        toast(error.message, 'err');
      }
    };
  }
  const replyMsgBtn = node.querySelector('[data-reply-msg]');
  if (replyMsgBtn) {
    replyMsgBtn.onclick = (event) => {
      event.stopPropagation();
      window.dispatchEvent(new CustomEvent('spokum:replyMessage', { detail: message }));
    };
  }
  return node;
}

async function openStickers(send) {
  const body = el('<div class="col" data-host style="gap:12px"></div>');
  const sheet = openSheet('Стикеры', body);

  const draw = async () => {
    let stickers = [];
    try {
      ({ stickers } = await api.stickers());
    } catch (error) {
      body.innerHTML = `<div class="small muted center">${esc(error.message)}</div>`;
      return;
    }

    body.innerHTML = `
      ${stickers.length
        ? `<div class="sticker-grid" data-grid>${stickers
            .map((sticker) => `<button data-send="${sticker.id}" data-image="${esc(sticker.image)}"><img src="${esc(sticker.image)}" alt=""></button>`)
            .join('')}</div>`
        : `<div class="small muted center" style="padding:14px 0">Своих стикеров пока нет</div>`}
      ${isPremium(state.user)
        ? `<div class="row" style="gap:8px">
            <button class="btn grow" data-add>${icon('plus', 16)} Добавить стикер</button>
            ${stickers.length ? `<button class="btn btn-sm" data-manage>${icon('trash', 15)}</button>` : ''}
          </div>`
        : `<div class="tiny muted center">Свои стикеры доступны с подпиской СпокУм Премиум</div>`}`;

    body.querySelectorAll('[data-send]').forEach((button) => {
      button.onclick = () => {
        send({ kind: 'sticker', media: button.dataset.image });
        sheet.close();
      };
    });

    body.querySelector('[data-add]')?.addEventListener('click', async () => {
      const image = await pickImage(320);
      if (!image) return;
      try {
        await api.addSticker(image);
        toast('Стикер добавлен');
        draw();
      } catch (error) {
        toast(error.message, 'err');
      }
    });

    body.querySelector('[data-manage]')?.addEventListener('click', () => {
      body.querySelectorAll('[data-send]').forEach((button) => {
        button.onclick = async () => {
          try {
            await api.removeSticker(Number(button.dataset.send));
            toast('Стикер удалён');
            draw();
          } catch (error) {
            toast(error.message, 'err');
          }
        };
      });
      toast('Нажмите на стикер, чтобы удалить');
    });
  };

  await draw();
}

export async function recordVoice(send, options = {}) {
  if (!navigator.mediaDevices?.getUserMedia) return toast('Микрофон недоступен', 'err');
  let stream;
  try {
    stream = await navigator.mediaDevices.getUserMedia({ audio: true });
  } catch {
    return toast('Нет доступа к микрофону', 'err');
  }
  const recorder = new MediaRecorder(stream);
  const chunks = [];
  const started = Date.now();
  recorder.ondataavailable = (event) => chunks.push(event.data);

  const body = el(`
    <div class="col center">
      <div class="row" style="justify-content:center;color:#c98b8b">${icon('mic', 28)}</div>
      <div class="strong" data-timer style="font-size:24px">0:00</div>
      <div class="row" style="gap:8px"><button class="btn grow" data-cancel>Отмена</button><button class="btn btn-primary grow" data-stop>Отправить</button></div>
    </div>`);
  const sheet = openSheet(options.title || 'Запись голосового', body);
  const limit = Number(options.limit) || 120;
  const timer = setInterval(() => {
    const spent = (Date.now() - started) / 1000;
    body.querySelector('[data-timer]').textContent = durationText(spent);
    if (spent >= limit) finish(true);
  }, 200);

  const finish = (keep) => {
    clearInterval(timer);
    recorder.onstop = () => {
      stream.getTracks().forEach((track) => track.stop());
      if (!keep) return;
      const blob = new Blob(chunks, { type: chunks[0]?.type || 'audio/webm' });
      const reader = new FileReader();
      reader.onload = () => send({ kind: 'voice', media: reader.result, duration: Math.round((Date.now() - started) / 1000) });
      reader.readAsDataURL(blob);
    };
    recorder.stop();
    sheet.close();
  };
  body.querySelector('[data-stop]').onclick = () => finish(true);
  body.querySelector('[data-cancel]').onclick = () => finish(false);
  recorder.start();
}

export async function sendPostToChat(post) {
  const { chats } = await api.chats();
  let people = [];
  try {
    const answer = await api.contacts();
    people = answer.contacts || [];
  } catch {}
  const known = new Set(chats.map((chat) => chat.peer?.id).filter(Boolean));
  const fresh = people.filter((person) => !known.has(person.id));
  if (!chats.length && !fresh.length) return toast('Сначала добавьте кого-нибудь в контакты', 'err');

  const body = el(`<div class="col" style="gap:6px">
    <input class="input" data-find placeholder="Кому отправить">
    <textarea class="textarea" data-note placeholder="Подпись, если хотите" style="min-height:54px"></textarea>
    <div class="col" data-list style="gap:6px"></div>
  </div>`);
  const sheet = openSheet('Отправить в чат', body);
  const list = body.querySelector('[data-list]');
  const note = body.querySelector('[data-note]');
  let busy = false;

  const rows = [
    ...chats.map((chat) => ({
      id: 'chat-' + chat.id,
      who: chat.peer || chat,
      title: chat.title || chat.peer?.displayName || 'Чат',
      hint: chat.peer ? '@' + chat.peer.username : 'беседа',
      open: async () => chat.id
    })),
    ...fresh.map((person) => ({
      id: 'user-' + person.id,
      who: person,
      title: person.displayName,
      hint: '@' + person.username,
      open: async () => {
        const { chat } = await api.createChat({ kind: 'dm', members: [person.id] });
        return chat.id;
      }
    }))
  ];

  const draw = (query) => {
    const found = rows.filter((row) => !query || (row.title + ' ' + row.hint).toLowerCase().includes(query));
    list.innerHTML = '';
    if (!found.length) {
      list.appendChild(el('<div class="tiny muted" style="padding:10px 4px">Никого не нашлось</div>'));
      return;
    }
    found.forEach((row) => {
      const node = el(`<button class="list-item">${avatar(row.who, 34)}<span class="grow" style="text-align:left"><span class="small strong truncate">${esc(row.title)}</span><span class="tiny muted"> ${esc(row.hint)}</span></span>${icon('forward', 15)}</button>`);
      node.onclick = async () => {
        if (busy) return;
        busy = true;
        node.disabled = true;
        try {
          const chatId = await row.open();
          await api.sendPost(chatId, post.id, note.value.trim());
          sheet.close();
          toast('Отправлено');
        } catch (error) {
          busy = false;
          node.disabled = false;
          toast(error.message, 'err');
        }
      };
      list.appendChild(node);
    });
  };

  draw('');
  body.querySelector('[data-find]').addEventListener('input', (event) => draw(event.target.value.trim().toLowerCase()));
  return sheet;
}

function openChatMenu(chat, view) {
  const body = el(`
    <div class="col" style="gap:6px">
      ${chat.kind !== 'dm' ? `<button class="list-item" data-members>${icon('users', 18)}<span>Участники (${chat.members.length})</span></button>` : ''}
      ${chat.kind !== 'dm' && chat.role === 'owner' ? `<button class="list-item" data-add>${icon('add_user', 18)}<span>Добавить участника</span></button>` : ''}
      ${chat.peer ? `<button class="list-item" data-contact>${icon('add_user', 18)}<span>Добавить в контакты</span></button>` : ''}
      ${chat.peer ? `<button class="list-item" data-report style="color:#c98b8b">${icon('flag', 18)}<span>Пожаловаться</span></button>` : ''}
      <button class="list-item" data-close>${icon('close', 18)}<span>Закрыть чат</span></button>
    </div>`);
  const sheet = openSheet(chat.title, body);
  body.querySelector('[data-members]')?.addEventListener('click', () => {
    sheet.close();
    openMembers(chat);
  });
  body.querySelector('[data-add]')?.addEventListener('click', async () => {
    sheet.close();
    const name = await promptSheet({ title: 'Добавить участника', label: 'Юзернейм', placeholder: '@username' });
    if (!name) return;
    try {
      const { user } = await api.getUser(name.replace(/^@/, ''));
      await api.addMember(chat.id, user.id);
      toast(`${user.displayName} в чате`);
    } catch (error) {
      toast(error.message, 'err');
    }
  });
  body.querySelector('[data-contact]')?.addEventListener('click', async () => {
    sheet.close();
    await api.addContact(chat.peer.id);
    toast('Добавлен в контакты');
  });
  body.querySelector('[data-report]')?.addEventListener('click', async () => {
    sheet.close();
    const { openReport } = await import('./feed.js?v=20251028');
    openReport('user', chat.peer.id);
  });
  body.querySelector('[data-close]').onclick = () => {
    sheet.close();
    view.remove();
    load(listRoot);
  };
}

function openMembers(chat) {
  const body = el(`<div class="col" style="gap:2px">${chat.members
    .map(
      (m) => `<button class="list-item" data-open="${esc(m.username)}">${avatar(m, 40)}<div class="grow"><div class="row" style="gap:6px"><span class="strong small">${esc(m.displayName)}</span>${badges(m)}</div><div class="tiny muted">@${esc(m.username)}${m.role === 'owner' ? ' · владелец' : ''}</div></div></button>`
    )
    .join('')}</div>`);
  const sheet = openSheet('Участники', body);
  body.querySelectorAll('[data-open]').forEach((button) => {
    button.onclick = () => {
      sheet.close();
      openProfile(button.dataset.open);
    };
  });
}

